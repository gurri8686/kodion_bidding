const User = require("../models/User");
const Job = require('../models/Job')
const AppliedJob = require('../models/Applyjob.js')
const UserTechnology = require('../models/UserTechnologies.js')
const Technology = require('../models/Technologies.js')
const sequelize = require('sequelize')
const ScrapeLog = require('../models/ScrapeLog')
const UserTechnologies = require('../models/UserTechnologies')
const IgnoredJob = require('../models/IgnoredJob')
const { Sequelize, Op } = require('sequelize');

const getAllUsers = async (req, res) => {
  const { search } = req.query;

  try {
    const whereClause = {
      role: { [Op.ne]: 'admin' } // 👈 exclude admins
    };
    if (search) {
      whereClause[Op.or] = [
        { firstname: { [Op.like]: `%${search}%` } },
        { lastname: { [Op.like]: `%${search}%` } },
        { email: { [Op.like]: `%${search}%` } }
      ];
    }

    const users = await User.findAll({
      where: whereClause,
      attributes: { exclude: ['password'] }
    });

    res.status(200).json(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};


const getUserCount = async (req, res) => {
  try {
    const totalUsers = await User.count();
    res.status(200).json({ totalUsers });
  } catch (error) {
    console.error('Error fetching user count:', error.message);
    res.status(500).json({ message: 'Internal server error' });
  }
};

const getJobCount = async (req, res) => {
  try {
    const totalJobs = await Job.count();
    res.status(200).json({ totalJobs });
  } catch (error) {
    console.error('Error fetching job count:', error.message);
    res.status(500).json({ message: 'Internal server error' });
  }
};

const getAppliedJobsCount = async (req, res) => {
  try {
    const totalAppliedJobs = await AppliedJob.count();
    res.status(200).json({ totalAppliedJobs });
  } catch (error) {
    console.error('Error fetching job count:', error.message);
    res.status(500).json({ message: 'Internal server error' });
  }
}

const getTopTechnologies = async (req, res) => {
  try {
    const result = await UserTechnology.findAll({
      attributes: [
        'technologyId',
        [sequelize.fn('COUNT', sequelize.col('userId')), 'userCount']
      ],
      where: { is_active: 1 },
      include: [
        {
          model: Technology,
          as: 'technology',        // must match association alias
          attributes: ['name']
        }
      ],
      group: ['technologyId', 'technology.id'],  // lowercase alias here
      order: [[sequelize.literal('userCount'), 'DESC']],
      limit: 10
    });

    // Format for frontend
    const formatted = result.map((entry) => ({
      technology: entry.technology.name,
      userCount: entry.get('userCount')
    }));

    res.json(formatted);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to load top technologies' });
  }
};


const getScrapeLogSummary = async (req, res) => {
  try {
    const logs = await ScrapeLog.findAll({
      attributes: [
        [Sequelize.fn('DATE', Sequelize.col('scrapedAt')), 'date'],
        [Sequelize.fn('SUM', Sequelize.col('jobCount')), 'totalJobs'],
      ],
      group: [Sequelize.fn('DATE', Sequelize.col('scrapedAt'))],
      order: [[Sequelize.fn('DATE', Sequelize.col('scrapedAt')), 'ASC']],
      raw: true,
    });

    res.status(200).json(logs);
  } catch (err) {
    console.error("Error fetching scrape log summary:", err);
    res.status(500).json({ error: err.message || "Something went wrong" });
  }
};

const getUserActivityDetails = async (req, res) => {
  console.log('called')
  try {
    const userId = req.params.id;

    // Basic user details
    const user = await User.findByPk(userId, {
      attributes: ['id', 'firstname', 'email', 'joinDate', 'lastActive'],
    });

    if (!user) {
      return res.status(404).json({ message: "User not found." });
    }

    // Applied jobs
    const appliedJobsCount = await AppliedJob.count({ where: { userId } });

    // Ignored jobs
    const ignoredJobsCount = await IgnoredJob.count({ where: { userId } });

    // Active technologies
    const activeTechs = await UserTechnologies.findAll({
      where: {
        userId,
        is_active: true,
      },
      include: [{
        model: Technology,
        as: 'technology',
        attributes: ['name'],
      }],
    });

    const activeTechnologies = activeTechs.map(item => item.technology.name);

    return res.json({
      id: user.id,
      name: user.firstname,
      email: user.email,
      joinDate: user.joinDate,
      lastActive: user.lastActive,
      appliedJobs: appliedJobsCount,
      ignoredJobs: ignoredJobsCount,
      activeTechnologies
    });

  } catch (error) {
    console.error("Error fetching user activity details:", error);
    res.status(500).json({ message: "Internal server error." });
  }
};

const toggleUserStatus = async (req, res) => {
  const userId = req.params.id;

  const { status } = req.body; // 'active' or 'blocked'
  console.log(req.params, "params")
  console.log(userId, "userId")
  if (!['active', 'blocked'].includes(status)) {
    return res.status(400).json({ message: 'Invalid status value' });
  }

  try {
    const user = await User.findByPk(userId);
    console.log(user, "user controller")
    if (!user) return res.status(404).json({ message: 'User not found' });

    user.status = status;
    await user.save();

    res.json({ message: `User ${status} successfully.` });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { getAllUsers, getUserCount, getJobCount, getAppliedJobsCount, getTopTechnologies, getScrapeLogSummary, getUserActivityDetails, toggleUserStatus };