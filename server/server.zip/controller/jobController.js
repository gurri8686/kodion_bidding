const Job = require("../models/Job");
const { Op, Sequelize } = require("sequelize");
const ScrapeLog = require("../models/ScrapeLog");
const AppliedJob = require("../models/Applyjob");
const TechnologyJobCount = require("../models/TechnologyJobCount");
const IgnoredJob = require('../models/IgnoredJob');

const saveJob = async (req, res) => {
  console.log("saveJob called");
  const { jobs, techJobCounts } = req.body;
  const saved = [];
  const duplicates = [];
  console.log(jobs.length, 'jobs.length')
  console.log(techJobCounts, 'techJobCounts received from frontend')

  if (!Array.isArray(jobs) || jobs.length === 0) {
    return res.status(400).json({ error: 'Invalid or empty job array' });
  }

  try {
    // Step 1: Create a temporary scrape log with count = 0
    const scrapeLog = await ScrapeLog.create({
      jobCount: 0, // temporary, will update after saving jobs
      scrapedAt: new Date(),
    });

    // ✅ Step 2: Process and save each job + calculate actual tech counts
    const actualTechCounts = {};

    for (const jobData of jobs) {
      const jobId = jobData.jobId;
      if (!jobId) continue;

      try {
        const existingJob = await Job.findOne({ where: { jobId } });
        if (existingJob) {
          duplicates.push(jobId);
          continue;
        }

        jobData.scrapeLogId = scrapeLog.id;
        const newJob = await Job.create(jobData);
        saved.push(newJob);

        // ✅ Count actual saved jobs by technology
        const tech = newJob.selectedTech;
        if (tech) {
          actualTechCounts[tech] = (actualTechCounts[tech] || 0) + 1;
        }

      } catch (err) {
        console.error(`Error creating jobId ${jobId}:`, err);
      }
    }

    // Step 3: Update the scrape log with the correct count of saved jobs
    await scrapeLog.update({ jobCount: saved.length });

    // ✅ Step 4: Save technology job counts (use actualTechCounts instead of frontend counts)
    console.log("Actual tech counts from saved jobs:", actualTechCounts);

    if (actualTechCounts && Object.keys(actualTechCounts).length > 0) {
      for (const [technology, count] of Object.entries(actualTechCounts)) {
        await TechnologyJobCount.create({
          scrapeLogId: scrapeLog.id,
          technology,
          count
        });
      }
    }

    console.log(`Saved jobs count: ${saved.length}`);
    console.log(`Duplicate jobs count: ${duplicates.length}`);

    return res.status(200).json({
      message: "Batch job insert complete",
      scrapeLogId: scrapeLog.id,
      saved_count: saved.length,
      duplicate_count: duplicates.length,
      actual_tech_counts: actualTechCounts, // ✅ Return actual counts
      frontend_tech_counts: techJobCounts, // ✅ Also return what frontend sent for comparison
      saved,
      duplicates
    });

  } catch (err) {
    console.error("Error saving jobs:", err);
    return res.status(500).json({ error: "Server error during job saving" });
  }
};

const getJobs = async (req, res) => {
  try {
    const {
      tech,
      rating,
      startDate,
      endDate,
      userId,
      title,
      page = 1,
      limit = 5,
      jobType,
      hourlyMinRate,
      hourlyMaxRate,
      fixedPriceRange,
      customFixedMin,
      customFixedMax,
    } = req.query;

    console.log("getJobs called with params:", req.query);

    const selectedTechs = tech ? (Array.isArray(tech) ? tech : [tech]) : [];
    const offset = (page - 1) * limit;
    const currentUserId = parseInt(userId);

    // Step 1: Get ignored and applied jobs
    const [ignoredJobs, appliedJobs] = await Promise.all([
      IgnoredJob.findAll({ where: { userId: currentUserId }, attributes: ['jobId'] }),
      AppliedJob.findAll({ where: { userId: currentUserId }, attributes: ['jobId'] }),
    ]);

    const excludedJobIds = [
      ...ignoredJobs.map(i => i.jobId),
      ...appliedJobs.map(a => a.jobId)
    ];

    // Step 2: Build base where condition
    let whereCondition = {};
    if (excludedJobIds.length > 0) {
      whereCondition.jobId = { [Op.notIn]: excludedJobIds };
    }

    if (title?.trim()) {
      whereCondition.title = { [Op.like]: `%${title.trim()}%` };
    }

    if (selectedTechs.length > 0) {
      whereCondition[Op.or] = [
        { selectedTech: { [Op.in]: selectedTechs } },
        ...selectedTechs.map(t => ({
          techStack: { [Op.like]: `%${t}%` },
        })),
      ];
    }

    if (rating) {
      whereCondition.rating = { [Op.gte]: parseFloat(rating) };
    }

    // ✅ Fix jobType filtering to handle "Fixed Price" or "Hourly"
    if (jobType) {
      const normalizedJobType = jobType.toLowerCase();
      if (normalizedJobType === "fixed") {
        whereCondition.jobType = { [Op.like]: "%fixed%" }; // allows "Fixed Price"
      } else if (normalizedJobType === "hourly") {
        whereCondition.jobType = { [Op.like]: "%hourly%" };
      }
    }

    // Date filters
    const now = new Date();
    const defaultStartDate = new Date(now);
    defaultStartDate.setDate(now.getDate() - 3);
    const formattedStart = new Date(startDate || defaultStartDate).toISOString().split("T")[0];
    const formattedEnd = new Date(endDate || now).toISOString().split("T")[0];

    whereCondition[Op.and] = [
      ...(whereCondition[Op.and] || []),
      Sequelize.where(
        Sequelize.fn("DATE", Sequelize.fn("STR_TO_DATE", Sequelize.col("exactDateTime"), "%d/%m/%Y, %r")),
        { [Op.gte]: formattedStart }
      ),
      Sequelize.where(
        Sequelize.fn("DATE", Sequelize.fn("STR_TO_DATE", Sequelize.col("exactDateTime"), "%d/%m/%Y, %r")),
        { [Op.lte]: formattedEnd }
      ),
    ];

    // Step 3: Fetch matching jobs
    let rawJobs = await Job.findAll({
      where: whereCondition,
      order: [
        [Sequelize.fn("STR_TO_DATE", Sequelize.col("exactDateTime"), "%d/%m/%Y, %r"), "DESC"]
      ],
    });

    // Step 4: Apply budget filters manually
    let filteredJobs = rawJobs;

    // 💰 Hourly Rate Filter
    if (jobType === "hourly" && (hourlyMinRate || hourlyMaxRate)) {
      const min = parseFloat(hourlyMinRate || 0);
      const max = parseFloat(hourlyMaxRate || Number.MAX_SAFE_INTEGER);

      filteredJobs = filteredJobs.filter(job => {
        const [minRate, maxRate] = job.hourlyRate
          ?.split("-")
          .map(str => parseFloat(str.replace(/[^0-9.]/g, ""))) || [0, 0];
        return minRate >= min && maxRate <= max;
      });
    }

    // 💰 Fixed Price Filter
    // 💰 Fixed Price Filter
    if (jobType === "fixed" && fixedPriceRange) {
      filteredJobs = filteredJobs.filter(job => {
        const price = parseFloat(job.fixedPrice?.replace(/[^0-9.]/g, "") || 0);

        switch (fixedPriceRange) {
          case "less-than-100":
            return price < 100;
          case "100-500":
            return price >= 100 && price <= 500;
          case "500-1k":
            return price > 500 && price <= 1000;
          case "1k-5k":
            return price > 1000 && price <= 5000;
          case "5k-20k":
            return price > 5000 && price <= 20000;
          case "20k-plus":
            return price > 20000;
          // case "custom":
          //   const min = parseFloat(customFixedMin || 0);
          //   const max = parseFloat(customFixedMax || Number.MAX_SAFE_INTEGER);
          //   return price >= min && price <= max;
          default:
            return true;
        }
      });
    }

    // Step 5: Paginate
    const paginatedJobs = filteredJobs.slice(offset, offset + parseInt(limit));

    // Step 6: Fetch all applied job records for flags
    const allAppliedRecords = await AppliedJob.findAll();
    const appliedMap = {};
    allAppliedRecords.forEach(({ jobId, userId: appliedUserId }) => {
      if (!appliedMap[jobId]) appliedMap[jobId] = [];
      appliedMap[jobId].push(appliedUserId);
    });

    const jobsWithFlags = paginatedJobs.map(job => {
      const jobId = job.jobId;
      const appliedUsers = appliedMap[jobId] || [];
      return {
        ...job.dataValues,
        isAppliedByUser: false,
        isAppliedByOtherUser: appliedUsers.length > 0,
      };
    });

    // Step 7: Return
    res.status(200).json({
      jobs: jobsWithFlags,
      totalCount: filteredJobs.length,
      currentPage: parseInt(page),
      totalPages: Math.ceil(filteredJobs.length / limit),
    });

  } catch (error) {
    console.error("Error fetching jobs:", error);
    res.status(500).json({ error: error.message });
  }
};


const getScrapelogs = async (req, res) => {
  try {
    const logs = await ScrapeLog.findAll({
      include: [
        {
          model: Job,
          as: 'jobs',
          attributes: ['jobId'], // or 'jobId' if you're storing that
        },
        {
          model: TechnologyJobCount,
          as: 'techCounts',
          attributes: ['technology', 'count'],
        }
      ],
      order: [['scrapedAt', 'DESC']],
    });

    const formattedLogs = logs.map(log => ({
      scrapeLogId: log.id,
      totalJobCount: log.jobCount,
      scrapedAt: log.scrapedAt,
      technologies: log.techCounts.map(tc => ({
        technology: tc.technology,
        count: tc.count
      }))
    }));

    res.status(200).json(formattedLogs);
  } catch (err) {
    console.error("Error fetching scrape logs:", err);
    res.status(500).json({ error: err.message || "Something went wrong" });
  }
};

module.exports = { saveJob, getJobs, getScrapelogs };
