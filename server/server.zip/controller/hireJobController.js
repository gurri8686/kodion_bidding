const { Op } = require("sequelize");
const HiredJob = require("../models/HiredJobs.js");
const Job = require("../models/Job");

const markHiredJob = async (req, res) => {
  try {
    const { jobId, bidderId, developerId, hiredAt, notes } = req.body;

    // Validation
    if (!jobId || !bidderId || !developerId || !hiredAt) {
      return res.status(400).json({ message: "Missing required fields." });
    }

    // Prevent duplicate hiring for same job
    const existing = await HiredJob.findOne({ where: { jobId } });
    if (existing) {
      return res.status(409).json({ message: "This job has already been marked as hired." });
    }

    // Create hired job entry
    const hiredJob = await HiredJob.create({
      jobId,
      bidderId,
      developerId,
      hiredAt,
      notes: notes || null
    });

    // Update job status in `jobs` table: appliedJobs -> 0, hiredJobs -> 1
    await Job.update(
      { appliedJobs: 0, hiredJobs: 1 },
      { where: { jobId } }
    );

    res.status(201).json({
      message: "Job successfully marked as hired.",
      hiredJob
    });

  } catch (error) {
    console.error("Error marking job as hired:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

const getHiredJobs = async (req, res) => {
  try {
    const { bidderId } = req.params;

    if (!bidderId) {
      return res.status(400).json({ message: "Missing bidderId in request params." });
    }

    const hiredJobs = await HiredJob.findAll({
      where: { bidderId },
      include: [
        {
          model: Job,
          as: 'jobDetails',
        }
      ],
      order: [['hiredAt', 'DESC']]
    });

    res.status(200).json({ hiredJobs });

  } catch (error) {
    console.error("Error fetching hired jobs:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};


module.exports = {
  markHiredJob,
  getHiredJobs
}
