const { Op, Sequelize } = require("sequelize");
const AppliedJob = require("../models/Applyjob.js");
const Job = require("../models/Job");
const IgnoredJob = require("../models/IgnoredJob");
const { v4: uuidv4 } = require('uuid');

exports.applyToJob = async (req, res) => {
  try {
    const {
      userId,
      jobId,
      jobTitle,
      jobDescription,
      upworkJobUrl,
      bidderName,
      profileName,
      technologies,
      connectsUsed,
      proposalLink,
      submitted,
    } = req.body;

    let job;

    if (jobId) {
      job = await Job.findOne({ where: { jobId } });
    }
    // Check for duplicate manual job title for the same user
    if (upworkJobUrl) {
      const existingManualJob = await AppliedJob.findOne({
        where: {
          userId,
          manualJobUrl: upworkJobUrl,
        },
      });

      if (existingManualJob) {
        return res.status(400).json({ message: 'You already applied for this job (based on URL)' });
      }
    }
    if (!job) {
      // If job does not exist, create one manually
      job = await await AppliedJob.create({
        userId,
        jobId: jobId || uuidv4(),
        bidderName,
        profileName,
        technologies,
        connectsUsed,
        proposalLink,
        submitted,
        manualJobTitle: jobTitle,
        manualJobDescription: jobDescription,
        manualJobUrl: upworkJobUrl,
      });
    }

    // // Check if user already applied
    // const alreadyApplied = await AppliedJob.findOne({ where: { userId, jobId: job.jobId } });
    // if (alreadyApplied) {
    //   return res.status(400).json({ message: "Already applied to this job" });
    // }

    // If user ignored this job before, remove ignore record
    const ignoredRecord = await IgnoredJob.findOne({ where: { userId, jobId: job.jobId } });
    if (ignoredRecord) {
      await ignoredRecord.destroy();
      job.ignoredJobs = false;
    }


    job.appliedJobs = true;
    await job.save();

    res.status(201).json({ message: "Applied job saved!", job });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error saving applied job" });
  }
};



exports.getAppliedJobs = async (req, res) => {
  try {
    const { userId } = req.params;
    const {
      tech,
      rating,
      startDate,
      endDate,
      page = 1,
      limit = 5,
      searchTerm,
    } = req.query;

    const offset = (parseInt(page) - 1) * parseInt(limit);

    // Filters to apply inside Job include
    let jobWhereCondition = {};
    if (rating) {
      jobWhereCondition.rating = { [Op.gte]: parseFloat(rating) };
    }

    if (startDate && endDate) {
      const formattedStart = new Date(startDate).toISOString().split("T")[0];
      const formattedEnd = new Date(endDate).toISOString().split("T")[0];

      jobWhereCondition[Op.and] = [
        Sequelize.where(Sequelize.fn("DATE", Sequelize.col("applied_at")), {
          [Op.gte]: formattedStart,
        }),
        Sequelize.where(Sequelize.fn("DATE", Sequelize.col("applied_at")), {
          [Op.lte]: formattedEnd,
        }),
      ];
    }

    if (tech) {
      const techArray = Array.isArray(tech) ? tech : [tech];
      jobWhereCondition[Op.or] = techArray.map((t) => ({
        [Op.or]: [
          { selectedTech: t },
          Sequelize.where(
            Sequelize.fn("JSON_CONTAINS", Sequelize.col("techStack"), `"${t}"`),
            1
          ),
        ],
      }));
    }

    // Main where condition on AppliedJob
    let appliedJobWhere = { userId };

    // Add searchTerm filter on both AppliedJob.manualJobTitle and Job.title
    if (searchTerm) {
      appliedJobWhere[Op.or] = [
        { manualJobTitle: { [Op.like]: `%${searchTerm}%` } },
        Sequelize.literal(`Job.title LIKE '%${searchTerm}%'`)
      ];
    }

    // Total count
    const totalCount = await AppliedJob.count({
      where: appliedJobWhere,
      include: [
        {
          model: Job,
          where: jobWhereCondition,
          required: false,
        },
      ],
    });

    // Fetch paginated applied jobs
    const appliedJobs = await AppliedJob.findAll({
      where: appliedJobWhere,
      include: [
        {
          model: Job,
          where: jobWhereCondition,
          required: false,
        },
      ],
      order: [["appliedAt", "DESC"]],
      offset,
      limit: parseInt(limit),
    });

    res.status(200).json({
      jobs: appliedJobs,
      totalCount,
      currentPage: parseInt(page),
      totalPages: Math.ceil(totalCount / limit),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error fetching applied jobs" });
  }
};


