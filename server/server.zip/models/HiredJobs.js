const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');
const Job = require('./Job'); // Make sure the path is correct
const Developer = require('./Developer'); // Make sure the path is correct
const HiredJob = sequelize.define('HiredJob', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  jobId: {
    type: DataTypes.STRING,
    allowNull: false,
    references: {
      model: 'jobs',
      key: 'jobId'
    }
  },
  bidderId: {
    type: DataTypes.STRING,
    allowNull: true
    // Optionally reference 'bidders' table
  },
  developerId: {
    type: DataTypes.STRING,
    allowNull: true,
    references: {
      model: 'developers',
      key: 'developerId'
    }
  },
  hiredAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  },
  notes: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  tableName: 'hired_jobs',
  timestamps: true
});

// ✅ Define association here
HiredJob.belongsTo(Job, {
  foreignKey: 'jobId',
  targetKey: 'jobId',
  as: 'jobDetails'
});
HiredJob.belongsTo(Developer, {
  foreignKey: 'developerId',
  targetKey: 'developerId',
  as: 'developerDetails' // ⚠️ used in include when querying
});


module.exports = HiredJob;
