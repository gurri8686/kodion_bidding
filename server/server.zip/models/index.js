const Job = require('./Job');
const User = require('./User');
const IgnoredJob = require('./IgnoredJob');
const HiredJob = require('./HiredJobs'); // Assuming this is the correct path for HiredJob
const ScrapeLog = require('./ScrapeLog');
const AppliedJob = require('./Applyjob'); // Assuming this is the correct path for AppliedJob
const Technologies = require('./Technologies');
const UserTechnologies = require('./UserTechnologies'); 
const TechnologyJobCount = require('./TechnologyJobCount')
const Developer = require('./Developer');
const models = { Job, User, AppliedJob, IgnoredJob, ScrapeLog,Technologies,UserTechnologies ,TechnologyJobCount,HiredJob,Developer};
console.log(Job);  // Check if Job is a valid Sequelize model
console.log(User);  // Check if User is a valid Sequelize model

// Define the associations after all models are loaded
Object.values(models).forEach(model => {
  if (typeof model.associate === 'function') {
    model.associate(models);
  }
});

module.exports = models;
