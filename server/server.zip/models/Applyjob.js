const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');
const Job = require("./Job");
const User = require('./User');

const AppliedJob = sequelize.define('AppliedJob', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  bidderName: {
    type: DataTypes.STRING,
    field: 'bidder_name',
  },
  profileName: {
    type: DataTypes.STRING,
    field: 'profile_name',
  },
  technologies: {
    type: DataTypes.JSONB, // Store technologies as JSONB (array) in PostgreSQL or MySQL
    field: 'technologies',
  },
  connectsUsed: {
    type: DataTypes.INTEGER,
    field: 'connects_used',
  },
  proposalLink: {
    type: DataTypes.STRING,
    field: 'proposal_link',
  },

  appliedAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    field: 'applied_at',
  },
  userId: {
    type: DataTypes.BIGINT(20).UNSIGNED,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id'
    }
  },
  manualJobTitle: {
    type: DataTypes.STRING,
    field: 'manual_job_title',
  },
  manualJobDescription: {
    type: DataTypes.TEXT,
    field: 'manual_job_description',
  },
  manualJobUrl: {
    type: DataTypes.STRING,
    field: 'manual_job_url',
  },
  jobId: {
    type: DataTypes.STRING, // ✅ match the type
    allowNull: true,
    references: {
      model: 'jobs',
      key: 'jobId', // ✅ foreign key will now succeed
    }
  }
}, {
  tableName: 'applied_jobs',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
  
});

// Relations
AppliedJob.associate = models => {
  AppliedJob.belongsTo(models.Job, {
    foreignKey: "jobId",
    targetKey: "jobId",
  });
  AppliedJob.belongsTo(models.User, {
    foreignKey: "userId"
  });
};



module.exports = AppliedJob;
