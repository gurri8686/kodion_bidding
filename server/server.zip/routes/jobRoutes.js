const express = require("express");
const {
  saveJob,
  getJobs,
  getScrapelogs,
} = require("../controller/jobController");

const {
  ignoreJob,
  getIgnoredJobs
} = require("../controller/ignoredJobs");

const {
  applyToJob,
  getAppliedJobs
} = require("../controller/applyJobController");

const { markHiredJob,getHiredJobs } = require("../controller/hireJobController");
const {
  ActivateTechnology,
  deactivateTechnology,
  gettechnologiesByUserId,
  getAllActiveTechnologies
} = require("../controller/technologyController");
const authenticate = require("../middleware/middleware");

const router = express.Router();

// Existing routes
router.post("/add", saveJob);
router.get("/get-jobs", getJobs);
router.post("/ignore", authenticate, ignoreJob);
router.get("/get-ignored-jobs", authenticate, getIgnoredJobs);
router.get("/applied-jobs/:userId", authenticate, getAppliedJobs); // Get applied jobs for a user

router.post("/apply-job", authenticate, applyToJob); // Apply to job
router.get("/scrape-logs", authenticate, getScrapelogs); // Get applied jobs for a user
router.post('/activate', authenticate, ActivateTechnology);
router.post('/deactivate', authenticate, deactivateTechnology);
router.get('/active/:userId', authenticate, gettechnologiesByUserId);
router.get('/all-active', getAllActiveTechnologies);

router.post("/mark-hired", authenticate, markHiredJob);
router.get("/get-hired-jobs/:bidderId", authenticate, getHiredJobs);
module.exports = router;
