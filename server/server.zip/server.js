const express = require('express');
const cors = require('cors');
const jobRoutes = require('./routes/jobRoutes');
const authRoutes = require("./routes/authRoutes");
const { connectDB, sequelize } = require('./config/db');
const adminRoutes = require('./routes/adminRoutes')
const path = require('path');
const cookieParser = require('cookie-parser');
const developerRoutes = require('./routes/developerRoutes');

require('dotenv').config();
const models = require('./models/index'); // Import all models from index.js
const { Job, ScrapeLog, User, IgnoredJob, AppliedJob, Technologies, UserTechnologies, TechnologyJobCount,Developer } = models;
const app = express();

// 🔥 IMPORTANT: Middleware must be configured BEFORE routes
app.use(cookieParser()); // Add this line BEFORE your routes

app.use(cors({
    // origin:'http://localhost:3000',
    origin: [
        'http://ec2-51-20-84-250.eu-north-1.compute.amazonaws.com:3000',
        'chrome-extension://lfnmgjkpcbabmbdjjnknamjmpegcdjai',
        'http://localhost:3000'
    ],
    // methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true,
}));

app.use((req, res, next) => {
    let size = parseInt(req.headers['content-length'] || '0');
    console.log(`Incoming payload size: ${size} bytes`);
    next();
});

// 🔥 Must come BEFORE any routes
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// ✅ API ROUTES MUST COME FIRST - BEFORE the catch-all route
app.use('/api/admin', adminRoutes);
app.use('/api/jobs', jobRoutes);
app.use("/api/auth", authRoutes);
app.use('/api', developerRoutes);

// ✅ Static files and catch-all route MUST COME AFTER API routes
const staticPath = path.join(__dirname, 'dist');
app.use(express.static(staticPath));

// ✅ This catch-all route should be LAST
app.get('*', (req, res) => {
  if (req.path.startsWith('/api') || req.path.includes('.')) {
    return res.status(404).send('Not Found');
  }
  res.sendFile(path.join(staticPath, 'index.html'));
});

const syncModels = async () => {
    try {
        await Job.sync({ alter: false, force: false });
        await IgnoredJob.sync({ alter: false, force: false });
        await User.sync({ alter: false, force: false });
        await AppliedJob.sync({ alter: false, force: false });
        await ScrapeLog.sync({ alter: false, force: false });
        await Technologies.sync({ alter: false, force: false });
        await UserTechnologies.sync({ alter: false, force: false });
        await TechnologyJobCount.sync({ alter: false, force: false });
        console.log('✅ All models synced safely without affecting data!');
    } catch (error) {
        console.error('❌ Error syncing models:', error);
    }
};

// Start server only after DB connection and sync
const startServer = async () => {
    try {
        await connectDB();      // Connect to MySQL
        await syncModels();     // Sync tables
        const PORT = 5000;
        app.listen(PORT, '0.0.0.0', () => {
            console.log(`🚀 Server running on port ${PORT}`);
        });
    } catch (error) {
        console.error('❌ Failed to start server:', error);
    }
};

startServer(); // 👈 Start everything