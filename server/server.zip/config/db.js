const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('bidding_tracking', 'bidding_dev', 'Kodion@2017', {
    host: '43.255.154.125',
    dialect: 'mysql',
    port: 3306, // default MySQL port
    logging: false, // optional: disables SQL logs in the console
});

const connectDB = async () => {
    try {
        await sequelize.authenticate();
        console.log('✅ Connected to MySQL database');
    } catch (err) {
        console.error('❌ Error connecting to MySQL:', err);
    }
};

module.exports = { sequelize, connectDB };
