import { useEffect, useState } from 'react';
import { Search, X } from 'lucide-react';

export default function JobSearch({
  setSearchTerm,
  searchTerm,
  handleclearSearch
}) {
  const [inputValue, setInputValue] = useState(searchTerm || '');
  const [error, setError] = useState('');

  useEffect(() => {
    setInputValue(searchTerm || '');
  }, [searchTerm]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const trimmedValue = inputValue.trim();

    if (!trimmedValue) {
      setError('Please enter a job title to search.');
      return;
    }

    setError('');
    setSearchTerm(trimmedValue);
  };

  const handleClearInput = () => {
    setInputValue('');
    setSearchTerm('');
    setError('');
    handleclearSearch(); // trigger clearing in parent if needed
  };

  return (
    <>
  
    <form onSubmit={handleSubmit} className="flex items-center gap-2 relative">
      <div className="relative lg:w-[20rem] w-[14rem]">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => {
            setInputValue(e.target.value);
            if (error) setError('');
          }}
          placeholder="Search job title..."
          className="border p-2 pr-10 rounded w-full"
        />
        {inputValue && (
          <button
            type="button"
            onClick={handleClearInput}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-red-600"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
      <button
        type="submit"
        className="p-2 bg-blue-500 hover:bg-blue-600 text-white rounded"
      >
        <Search className="w-6 h-6" />
      </button>
      
    </form>
        {error && <p className="text-red-500 text-sm mt-1">{error}</p>}

    </>
  );
}
