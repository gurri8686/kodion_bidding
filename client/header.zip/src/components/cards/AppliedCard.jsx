import {
    MapPin,
    DollarSign,
    Clock,
    Star,
    User2,
    Layers,
    Zap,
} from "lucide-react";
import { useState } from "react";
import HiredJobModal from "../../modals/HiredJob";
import EditAppliedJobModal from "../../modals/EditAppliedModal";
export default function CompactJobCard({ job,fetchAppliedJobs }) {
    const [isHiredModalOpen, setIsHiredModalOpen] = useState(false);
    const [selectedJobId, setSelectedJobId] = useState(null);
      const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  
    const isManualJob = !job.Job || !job.Job.scrapeLogId;

    const safeJsonParse = (jsonString, fallback = []) => {
        try {
            return jsonString ? JSON.parse(jsonString) : fallback;
        } catch {
            return fallback;
        }
    };
  const handleEditJob = () => {
        setIsEditModalOpen(true);
    };
    const handleMarkAsHired = (jobId) => {
        setSelectedJobId(jobId);
        setIsHiredModalOpen(true);
    };

    const handleHiredSubmit = (hiredData) => {
        // handle hired data submission
        setIsHiredModalOpen(false);
    };

    const title = job.manualJobTitle || job.Job?.title || "No Title";
    const jobLink = job.Job?.link || job.manualJobUrl;
    const jobLocation = job.Job?.clientLocation || "";
    const jobRate = job.Job?.hourlyRate || job.Job?.fixedPrice || "";
    const jobDuration = job.Job?.estimatedDuration || "";
    const jobRating = job.Job?.rating;
    const appliedDate = new Date(job.appliedAt).toLocaleString(undefined, {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
    });
    const technologies = safeJsonParse(job.technologies);

    return (
        <div className="relative group bg-white border rounded-lg shadow-sm p-4 hover:shadow-md transition-all">
            <div className="flex justify-between items-start mb-2">
                <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
                {isManualJob && (
                    <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">
                        Manual
                    </span>
                )}
            </div>

            {/* Core Job Details */}
            <div className="text-sm text-gray-600 space-y-1">
                <div className="flex items-center gap-1">
                    <User2 size={14} />
                    <span className="font-medium">Profile:</span> {job?.profile?.name || "N/A"}
                </div>
                <div className="flex items-center gap-1">
                    <Zap size={14} />
                    <span className="font-medium">Connects Used:</span> {job.connectsUsed || 0}
                </div>
                {technologies.length > 0 && (
                    <div className="flex items-center gap-1 flex-wrap">
                        <Layers size={14} />
                        <span className="font-medium mr-1">Technologies:</span>
                        {technologies.map((tech, index) => (
                            <span
                                key={index}
                                className="bg-blue-100 text-blue-800 text-xs px-2 py-0.5 rounded mr-1 mt-1"
                            >
                                {tech}
                            </span>
                        ))}
                    </div>
                )}
                {jobLocation && (
                    <div className="flex items-center gap-1">
                        <MapPin size={14} /> {jobLocation}
                    </div>
                )}
                {jobRate && (
                    <div className="flex items-center gap-1">
                        <DollarSign size={14} /> {jobRate}
                    </div>
                )}
                {jobDuration && (
                    <div className="flex items-center gap-1">
                        <Clock size={14} /> {jobDuration}
                    </div>
                )}
                {jobRating && jobRating !== "0.0" && (
                    <div className="flex items-center gap-1">
                        <Star size={14} className="text-yellow-500 fill-yellow-500" />
                        {jobRating}
                    </div>
                )}
            </div>

            <div className="mt-3 text-xs text-gray-500">
                Applied on: {appliedDate}
            </div>

            {/* Hover-only Footer Actions */}
            <div className="absolute bottom-3 right-4 opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-200 ease-in-out text-sm flex gap-4">
                <a href={job.proposalLink} className="text-blue-600 underline">
                    Proposal
                </a>
                {jobLink && (
                    <a href={jobLink} className="text-blue-600 underline">
                        Job
                    </a>
                )}
                <button
                    className="text-green-600 underline"
                    onClick={() => handleMarkAsHired(job.id)}
                >
                    Mark Hired
                </button>
                  <button
                    className="text-yellow-600 underline"
                    onClick={handleEditJob}
                >
                    Edit
                </button>
            </div>

            {/* Modal */}
            <HiredJobModal
                isOpen={isHiredModalOpen}
                onClose={() => setIsHiredModalOpen(false)}
                onHiredSubmit={handleHiredSubmit}
                jobId={selectedJobId}
                jobTitle={title}
                job={job}
                fetchAppliedJobs={fetchAppliedJobs}
            />
            <EditAppliedJobModal
                isOpen={isEditModalOpen}
                onClose={() => setIsEditModalOpen(false)}
                job={job}
                fetchAppliedJobs={fetchAppliedJobs}
            />
        </div>
    );
}





