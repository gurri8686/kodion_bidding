import {
   CalendarCheck, DollarSign, FileText, User, Mail, Phone
} from 'lucide-react';

const HiredJobsCard = ({ job }) => {
  const {
    jobDetails,
    developerDetails,
    hiredAt,
    notes,
    budgetAmount,
    budgetType,
    clientName,
    profileName
  } = job;

  
  return (
    <div className="bg-white border rounded-xl p-4 shadow-sm hover:shadow-md transition-all text-sm space-y-3">
      {/* Job Title + Client */}
      <div className="flex justify-between items-start">
        <div>
          {jobDetails?.link ? (
            <a
              href={jobDetails.link}
              target="_blank"
              rel="noopener noreferrer"
              className="text-base font-semibold text-blue-700 hover:underline flex items-center gap-1"
            >
              {jobDetails.title}
            </a>
          ) : (
            <h2 className="text-base font-semibold text-blue-700">
              {jobDetails?.title || 'Untitled Job'}
            </h2>
          )}
          <p className="text-gray-500">
            <span className="font-medium">Client:</span> {clientName} &bull; <span className="font-medium">Profile:</span> {profileName}
          </p>
        </div>
   
      </div>

      {/* Description */}
      {jobDetails?.shortDescription && (
        <p className="text-gray-700 line-clamp-2">
          {jobDetails.shortDescription}
        </p>
      )}

      {/* Budget + Time + Notes */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-gray-600">
        <div className="flex items-center gap-2">
          <DollarSign size={14} />
          <span>
            <strong>Budget:</strong> {budgetAmount} USD ({budgetType})
          </span>
        </div>
        <div className="flex items-center gap-2">
          <CalendarCheck size={14} />
          <span>
            <strong>Hired:</strong> {new Date(hiredAt).toLocaleDateString()}

          </span>
        </div>
        {notes && (
          <div className="sm:col-span-2 flex items-start gap-2">
            <FileText size={14} className="mt-1" />
            <span className="italic">
              <strong>Notes:</strong> {notes}
            </span>
          </div>
        )}
      </div>

      {/* Developer Info */}
      <div className="grid grid-cols-1 sm:grid-cols-1 gap-2 text-gray-700 border-t pt-3">
        <h2 className='font-semibold'>Assigned Developer Info</h2>
        <div className="flex items-center gap-2">
          <User size={14} />
          {developerDetails?.name || "N/A"}
        </div>
        <div className="flex items-center gap-2">
          <Mail size={14} />
          {developerDetails?.email || "N/A"}
        </div>
        <div className="flex items-center gap-2">
          <Phone size={14} />
          {developerDetails?.contact || "N/A"}
        </div>
      </div>
    </div>
  );
};

export default HiredJobsCard;
