import React, { useEffect, useState } from "react";
import Modal from "react-modal";
import { Formik, Form, Field, ErrorMessage } from "formik";
import Select from "react-select";
import { useSelector } from "react-redux";
import { editJobSchema } from "../utils/validations"; // Or use a separate edit schema
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

Modal.setAppElement("#root");

const EditAppliedJobModal = ({ isOpen, onClose, job, fetchAppliedJobs }) => {
    const { user, token } = useSelector((state) => state.auth);
    console.log(job, "job in EditAppliedJobModal");
    const [techOptions, setTechOptions] = useState([]);
    const [profileOptions, setProfileOptions] = useState([]);

    const fetchTechnologies = async () => {
        try {
            const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/jobs/all-technology-names`);
            const data = await response.json();
            if (Array.isArray(data.technologies)) {
                const formatted = data.technologies.map((tech) => ({ value: tech, label: tech }));
                setTechOptions(formatted);
            }
        } catch (err) {
            console.error("Error fetching technologies:", err);
        }
    };
    const fetchProfiles = async () => {
        try {
            const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/get-all-profiles`, {
                method: "GET",
                headers: { Authorization: `Bearer ${token}` },
            });
            const data = await response.json();
            console.log("Fetched profiles:", data);
            if (Array.isArray(data)) {
                const formatted = data.map(profile => ({
                    value: profile.id,
                    label: profile.name,
                }));

                console.log("Setting profileOptions:", formatted);
                setProfileOptions(formatted);
            }
        } catch (err) {
            console.error("Error fetching profiles:", err);
        }
    };

    useEffect(() => {
        if (token) {
            fetchTechnologies();
            fetchProfiles();
        }
    }, [token]);
    const handleSubmit = async (values) => {
        console.log("Submitting form with values:", values);
        console.log("Job ID:", job.id) // Add this
        try {
            const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/jobs/edit-apply-job/${job.id}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify({
                    manualJobTitle: values.manualJobTitle,
                    profileId: values.profileId,
                    technologies: values.technologies,
                    connectsUsed: Number(values.connectsUsed),
                    proposalLink: values.proposalLink,
                    manualJobUrl: values.manualJobUrl,
                })
            });

            const result = await response.json();
            console.log("Edit job response:", result); // Add this

            if (response.ok) {
                toast.success("Job updated successfully!");
                fetchAppliedJobs();
                onClose();
            } else {
                toast.error(result.message || "Failed to update job");
            }
        } catch (err) {
            console.error("Error in handleSubmit:", err);
            toast.error("Something went wrong. Please try again.");
        }
    };

    if (!isOpen) return null;

    return (
        <>
            <ToastContainer position="top-center" autoClose={2000} />
            <Modal
                isOpen={isOpen}
                onRequestClose={onClose}
                contentLabel="Edit Applied Job Modal"
                className="bg-white p-6  mx-4 -mt-[0.7rem] rounded-lg shadow-md lg:w-1/3 w-full lg:mx-auto outline-none z-50"
                overlayClassName="fixed inset-0 bg-black bg-opacity-30 flex justify-center items-center z-40"
            >
                <h2 className="text-xl font-bold mb-4">Edit Applied Job</h2>
                <Formik
                    initialValues={{
                        manualJobTitle: job.manualJobTitle || job.Job?.title || "",
                        profileName: job?.profile?.name || "",
                        proposalLink: job.proposalLink || "",
                        manualJobUrl: job.manualJobUrl || "",
                        technologies: Array.isArray(job.technologies)
                            ? job.technologies
                            : typeof job.technologies === "string"
                                ? JSON.parse(job.technologies)
                                : [],
                        connectsUsed: job.connectsUsed || 0,
                        profileId: job.profile?.id || "",
                    }}
                    validationSchema={editJobSchema}
                    onSubmit={handleSubmit}
                    enableReinitialize
                >
                    {({ setFieldValue, values }) => (
                        <Form className="space-y-4">
                            <div>
                                <label className="block font-medium">Job Title</label>
                                <Field name="manualJobTitle" className="w-full border px-3 py-2 rounded" />
                                <ErrorMessage name="manualJobTitle" component="div" className="text-red-500 text-sm" />
                            </div>

                            <div>
                                <label className="block font-medium">Upwork Profile</label>
                                <Select
                                    name="profileId"
                                    value={profileOptions.find(opt => opt.value === values.profileId) || null}
                                    onChange={(option) => setFieldValue("profileId", option.value)}
                                    options={profileOptions}
                                    className="w-full"
                                />
                                <ErrorMessage name="profileId" component="div" className="text-red-500 text-sm" />
                            </div>
                            <div>
                                <label className="block font-medium">Technologies</label>
                                <Select
                                    isMulti
                                    name="technologies"
                                    value={values.technologies.map(t => ({ value: t, label: t }))}
                                    onChange={(options) =>
                                        setFieldValue("technologies", options.map(opt => opt.value))
                                    }
                                    options={techOptions}
                                    className="w-full"
                                />
                                <ErrorMessage name="technologies" component="div" className="text-red-500 text-sm" />
                            </div>

                            <div>
                                <label className="block font-medium">Connects Used</label>
                                <Field name="connectsUsed" type="number" className="w-full border px-3 py-2 rounded" />
                                <ErrorMessage name="connectsUsed" component="div" className="text-red-500 text-sm" />
                            </div>
                            <div>
                                <label className="block font-medium">Proposal Link</label>
                                <Field name="proposalLink" className="w-full border px-3 py-2 rounded" />
                                <ErrorMessage name="proposalLink" component="div" className="text-red-500 text-sm" />
                            </div>

                            <div>
                                <label className="block font-medium">Job URL</label>
                                <Field name="manualJobUrl" className="w-full border px-3 py-2 rounded" />
                                <ErrorMessage name="manualJobUrl" component="div" className="text-red-500 text-sm" />
                            </div>
                            <div className="flex justify-end gap-3 mt-5">
                                <button type="button" className="px-4 py-2 bg-gray-300 rounded" onClick={onClose}>
                                    Cancel
                                </button>
                                <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded">
                                    Save
                                </button>
                            </div>
                        </Form>
                    )}
                </Formik>
            </Modal>
        </>
    );
};

export default EditAppliedJobModal;
