import { useEffect, useState } from "react";
import { X, UserCheck, Calendar, FileText, Users, User } from "lucide-react";
import axios from "axios";
import { useSelector } from "react-redux";
import { Formik, Form, Field, ErrorMessage } from "formik";
import { hiredJobSchema } from "../utils/validations";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function HiredJobModal({ isOpen, onClose, onHiredSubmit, jobTitle, jobId, job,fetchAppliedJobs }) {
    console.log(job, "job");
    console.log(jobId, "jobId");
    const [developers, setDevelopers] = useState([]);
    const [loading, setLoading] = useState(false);
    const token = useSelector((state) => state.auth.token);
    const userId = useSelector((state) => state.auth.userId);
    
    useEffect(() => {
        if (!isOpen) return;

        const fetchDevelopers = async () => {
            setLoading(true);
            try {
                const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/get-all-developers`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setDevelopers(res.data || []);
            } catch (error) {
                console.error("Error fetching developers:", error);
                alert("Failed to fetch developers.");
            } finally {
                setLoading(false);
            }
        };

        fetchDevelopers();
    }, [isOpen, token]);



    const handleSubmit = async (values, { setSubmitting, resetForm }) => {
        const hiredDateTime = values.hiredTime
            ? `${values.hiredDate}T${values.hiredTime}`
            : `${values.hiredDate}T00:00`;

        const payload = {
            jobId:job.jobId,
            bidderId: userId,
            developerId: values.selectedDeveloper,
            hiredAt: hiredDateTime,
            notes: values.notes,
            budgetType: values.budgetType,
            budgetAmount: values.budgetAmount,
            profileName: values.ProfileName,
            clientName: values.ClientName,
        };
        console.log(payload, "payload");
        try {
            await axios.post(
                `${import.meta.env.VITE_API_BASE_URL}/api/jobs/mark-hired`,
                payload,
                {
                    headers: { Authorization: `Bearer ${token}` },
                }
            );
            toast.success("Job marked as hired successfully.");
            resetForm();
            onClose();
            fetchAppliedJobs();
        } catch (error) {
            console.error("Error submitting hired job:", error);
            toast.error(error?.response?.data?.message || "Failed to mark as hired.");
        } finally {
            setSubmitting(false);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 overflow-y-auto">
            <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose}></div>
            <ToastContainer position="top-center" autoClose={2000} />
            <div className="flex min-h-full items-center justify-center p-4">
                <div className="relative bg-white rounded-lg shadow-xl max-w-md w-full mx-4">
                    <div className="flex items-center justify-between p-6 border-b border-gray-200">
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-emerald-100 rounded-lg">
                                <UserCheck className="w-5 h-5 text-emerald-600" />
                            </div>
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900">Mark as Hired</h3>
                                <p className="text-sm text-gray-500 truncate">{jobTitle}</p>
                            </div>
                        </div>
                        <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-full">
                            <X className="w-5 h-5 text-gray-400" />
                        </button>
                    </div>

                    <Formik
                        initialValues={{
                            selectedDeveloper: "",
                            hiredDate: "",
                            notes: "",
                            budgetType: "",
                            budgetAmount: "",
                            ProfileName: job?.profileName,
                            ClientName: "",
                        }}
                        validationSchema={hiredJobSchema}
                        onSubmit={handleSubmit}
                    >
                        {({ isSubmitting }) => (
                            <Form className="p-6 space-y-6">
                                <div>
                                    <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                                        <User className="w-4 h-4" />
                                        Profile Name
                                    </label>
                                    <Field
                                        type="text"
                                        name="ProfileName"
                                        value={job?.profileName}
                                        readOnly
                                        className="w-full px-3 py-2 border border-gray-300 rounded-md"
                                    />
                                    <ErrorMessage name="ProfileName" component="div" className="text-red-500 text-sm mt-1" />
                                </div>
                                <div>
                                    <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                                        <Users className="w-4 h-4" />
                                        Client Name
                                    </label>
                                    <Field
                                        type="text"
                                        name="ClientName"
                                        className="w-full px-3 py-2 border border-gray-300 rounded-md"
                                    />
                                    <ErrorMessage name="ClientName" component="div" className="text-red-500 text-sm mt-1" />
                                </div>
                                <div>
                                    <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                                        <FileText className="w-4 h-4" />
                                        Budget Type
                                    </label>
                                    <Field
                                        as="select"
                                        name="budgetType"
                                        className="w-full px-3 py-2 border border-gray-300 rounded-md"
                                    >
                                        <option value="">Select Budget Type</option>
                                        <option value="Hourly">Hourly</option>
                                        <option value="Fixed">Fixed</option>
                                    </Field>
                                    <ErrorMessage name="budgetType" component="div" className="text-red-500 text-sm mt-1" />
                                </div>

                                <div>
                                    <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                                        <FileText className="w-4 h-4" />
                                        Budget Amount
                                    </label>
                                    <Field
                                        type="number"
                                        name="budgetAmount"
                                        className="w-full px-3 py-2 border border-gray-300 rounded-md"
                                        placeholder="Enter budget amount"
                                    />
                                    <ErrorMessage name="budgetAmount" component="div" className="text-red-500 text-sm mt-1" />
                                </div>
                                <div>
                                    <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                                        <Users className="w-4 h-4" />
                                        Select Developer
                                    </label>
                                    <Field
                                        as="select"
                                        name="selectedDeveloper"
                                        className="w-full px-3 py-2 border border-gray-300 rounded-md"
                                    >
                                        <option value="">Choose a developer...</option>
                                        {loading ? (
                                            <option disabled>Loading...</option>
                                        ) : (
                                            developers.map((dev) => (
                                                <option key={dev.developerId} value={dev.developerId}>
                                                    {dev.name}
                                                </option>
                                            ))
                                        )}
                                    </Field>
                                    <ErrorMessage name="selectedDeveloper" component="div" className="text-red-500 text-sm mt-1" />
                                </div>

                                <div>
                                    <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                                        <Calendar className="w-4 h-4" />
                                        Hired Date
                                    </label>
                                    <Field
                                        type="date"
                                        name="hiredDate"
                                        className="w-full px-3 py-2 border border-gray-300 rounded-md"
                                    />
                                    <ErrorMessage name="hiredDate" component="div" className="text-red-500 text-sm mt-1" />
                                </div>




                                <div>
                                    <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                                        <FileText className="w-4 h-4" />
                                        Internal Notes (Optional)
                                    </label>
                                    <Field
                                        as="textarea"
                                        name="notes"
                                        rows={4}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-md resize-none"
                                    />
                                    <ErrorMessage name="notes" component="div" className="text-red-500 text-sm mt-1" />
                                </div>

                                <div className="flex gap-3 pt-4">
                                    <button
                                        type="button"
                                        onClick={onClose}
                                        className="flex-1 px-4 py-2.5 text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        type="submit"
                                        disabled={isSubmitting}
                                        className="flex-1 px-4 py-2.5 bg-emerald-500 text-white rounded-md hover:bg-emerald-600 flex items-center justify-center gap-2"
                                    >
                                        <UserCheck className="w-4 h-4" />
                                        {isSubmitting ? "Submitting..." : "Mark as Hired"}
                                    </button>
                                </div>
                            </Form>
                        )}
                    </Formik>
                </div>
            </div>
        </div>
    );
}
