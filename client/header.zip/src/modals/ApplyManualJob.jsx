import Modal from "react-modal";
import { useSelector } from "react-redux";
import { toast, ToastContainer } from "react-toastify";
import Select from "react-select";
import { useFormik } from "formik";
import { useEffect, useState } from "react";
import "react-toastify/dist/ReactToastify.css";
import { applyManualJobSchema } from "../utils/validations";
Modal.setAppElement("#root");

const ApplyManualJob = ({ isOpen, onRequestClose, onApplyJob, fetchAppliedJobs }) => {
  const { user, token } = useSelector((state) => state.auth);
  const [techOptions, setTechOptions] = useState([]);
  const [profileOptions, setProfileOptions] = useState([]);
  const fetchTechOptions = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/jobs/all-technology-names`);
      const data = await response.json();

      if (Array.isArray(data.technologies)) {
        const formatted = data.technologies.map(tech => ({
          label: tech,
          value: tech
        }));
        setTechOptions(formatted);
      } else {
        console.warn("Unexpected format:", data);
      }
    } catch (err) {
      console.error("Error fetching technologies:", err);
    }
  };
  const fetchProfiles = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/get-all-profiles`, {
        method: "GET",
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await response.json();
      console.log("Fetched profiles:", data);
      if (Array.isArray(data)) {
        const formatted = data.map(profile => ({
          value: profile.id,
          label: profile.name,
        }));
        console.log("Setting profileOptions:", formatted);
        setProfileOptions(formatted);
      }
    } catch (err) {
      console.error("Error fetching profiles:", err);
    }
  };
  useEffect(() => {
    fetchProfiles();
    fetchTechOptions();
  }, []);

  const formik = useFormik({
    initialValues: {
      jobTitle: "",
      jobDescription: "",
      // clientName: "",
      upworkJobUrl: "",
      bidderName: user?.firstname + " " + user?.lastname || "",
      profileId: "",
      technologies: [],
      connects: "",
      proposalLink: "",
      appliedDate: new Date().toISOString().split("T")[0],
    },
    validationSchema: applyManualJobSchema,
    onSubmit: async (values, { setSubmitting, resetForm }) => {
      try {
        const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/jobs/apply-job`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          credentials: "include",
          body: JSON.stringify({
            userId: user.id,
            ...values,
            connectsUsed: Number(values.connects),
            appliedAt: values.appliedDate,
          }),
        });

        if (res.status === 201) {
          toast.success("Job applied successfully!");
          resetForm();
          onApplyJob();
          onRequestClose();
          fetchAppliedJobs(1);
        } else if (res.status === 400) {
          toast.error("You already applied for this job.");
        }
      } catch (error) {
        console.error("Error submitting job:", error);
        toast.error("Something went wrong. Please try again.");
      } finally {
        setSubmitting(false);
      }
    },
  });



  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={onRequestClose}
      contentLabel="Add Manual Job Entry"
      className="bg-white p-6 rounded-lg shadow-lg w-11/12 max-w-2xl mx-auto outline-none z-50 max-h-[90vh] overflow-y-auto"
      overlayClassName="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-start pt-8 z-40"
    >
      <ToastContainer position="top-center" autoClose={2000} />
      <div className="sticky -top-[23px] bg-white pb-4 mb-4 border-b">
        <h2 className="text-2xl font-bold text-gray-900">Add Manual Job Entry</h2>
      </div>

      <form onSubmit={formik.handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <input name="jobTitle" placeholder="Job Title" value={formik.values.jobTitle} onChange={formik.handleChange} onBlur={formik.handleBlur} className="border p-2 rounded w-full" />
            {formik.touched.jobTitle && formik.errors.jobTitle && <div className="text-red-500 text-sm">{formik.errors.jobTitle}</div>}
          </div>

          {/* <div>
            <input name="clientName" placeholder="Client Name" value={formik.values.clientName} onChange={formik.handleChange} onBlur={formik.handleBlur} className="border p-2 rounded w-full" />
            {formik.touched.clientName && formik.errors.clientName && <div className="text-red-500 text-sm">{formik.errors.clientName}</div>}
          </div> */}


          <div>
            <input name="upworkJobUrl" placeholder="Upwork Job URL" value={formik.values.upworkJobUrl} onChange={formik.handleChange} onBlur={formik.handleBlur} className="border p-2 rounded w-full" />
            {formik.touched.upworkJobUrl && formik.errors.upworkJobUrl && <div className="text-red-500 text-sm">{formik.errors.upworkJobUrl}</div>}
          </div>

          {/* <div>
            <input name="bidderName" placeholder="Bidder Name" value={formik.values.bidderName} onChange={formik.handleChange} onBlur={formik.handleBlur} className="border p-2 rounded w-full" />
            {formik.touched.bidderName && formik.errors.bidderName && <div className="text-red-500 text-sm">{formik.errors.bidderName}</div>}
          </div> */}

          <div className="col-span-2">
          <Select
  name="profileId"
  value={profileOptions.find(opt => opt.value === formik.values.profileId) || null}
  onChange={(option) => formik.setFieldValue("profileId", option.value)}
  onBlur={() => formik.setFieldTouched("profileId", true)}
  options={profileOptions}
  className="w-full"
  placeholder="Select Profile"
/>

{formik.touched.profileId && formik.errors.profileId && (
  <div className="text-red-500 text-sm">{formik.errors.profileId}</div>
)}
          </div>

          <div className="col-span-2">
            <Select
              isMulti
              name="technologies"
              value={formik.values.technologies.map((val) => ({ label: val, value: val }))}
              onChange={(opts) => formik.setFieldValue("technologies", opts.map((o) => o.value))}
              onBlur={() => formik.setFieldTouched("technologies", true)}
              options={techOptions}
              placeholder="Select Technologies"
            />
            {formik.touched.technologies && formik.errors.technologies && <div className="text-red-500 text-sm">{formik.errors.technologies}</div>}
          </div>

          <div>
            <input name="connects" type="number" placeholder="Connects Used" value={formik.values.connects} onChange={formik.handleChange} onBlur={formik.handleBlur} className="border p-2 rounded w-full" />
            {formik.touched.connects && formik.errors.connects && <div className="text-red-500 text-sm">{formik.errors.connects}</div>}
          </div>

          <div>
            <input name="proposalLink" placeholder="Proposal Link" value={formik.values.proposalLink} onChange={formik.handleChange} onBlur={formik.handleBlur} className="border p-2 rounded w-full" />
            {formik.touched.proposalLink && formik.errors.proposalLink && <div className="text-red-500 text-sm">{formik.errors.proposalLink}</div>}
          </div>
        </div>

        <div className="flex justify-end gap-3 mt-6 pt-4 border-t">
          <button type="button" onClick={onRequestClose} className="px-4 py-2 text-gray-700 bg-gray-200 hover:bg-gray-300 rounded-md">
            Cancel
          </button>
          <button type="submit" disabled={formik.isSubmitting} className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
            {formik.isSubmitting ? "Submitting..." : "Add Job Entry"}
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default ApplyManualJob;
