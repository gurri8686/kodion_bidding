// import React from 'react'
// import {
//     MapPin,
//     DollarSign,
//     Briefcase,
//     User2,
//     Clock,
//     Star,
// } from "lucide-react";

// const AppliedJobsCard = ({ job, safeJsonParse, isManualJob }) => {
//     const parsedTechnologies = safeJsonParse(job.technologies);
//     const parsedTechStack = job.Job?.techStack ? safeJsonParse(job.Job.techStack) : [];

//     return (
//         <div className="h-full">
//             <div
//                 key={job.id}
//                 className="bg-white p-4 shadow-sm rounded-md border border-gray-200 hover:shadow-md transition-shadow duration-200 h-full flex flex-col justify-between"
//             >
//                 <div className="flex flex-col gap-4">
//                     {/* Header Section */}
//                     <div className="flex flex-col md:flex-row justify-between gap-6">
//                         <div className="flex-1">
//                             <div className="flex items-center gap-2 mb-1">
//                                 <h3 className="text-lg font-semibold text-gray-900 truncate">
//                                     {job.manualJobTitle || job.Job?.title || 'No Title'}
//                                 </h3>
//                                 {isManualJob && (
//                                     <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full font-medium">
//                                         Manual Entry
//                                     </span>
//                                 )}
//                             </div>
//                             <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm text-gray-600">
//                                 {job.Job?.clientLocation && (
//                                     <div className="flex items-center">
//                                         <MapPin size={14} className="mr-1" />
//                                         {job.Job.clientLocation}
//                                     </div>
//                                 )}
//                                 {(job.Job?.hourlyRate || job.Job?.fixedPrice) && (
//                                     <div className="flex items-center">
//                                         <DollarSign size={14} className="mr-1" />
//                                         {job.Job.hourlyRate || job.Job.fixedPrice}
//                                     </div>
//                                 )}
//                                 {job.Job?.estimatedDuration && (
//                                     <div className="flex items-center">
//                                         <Clock size={14} className="mr-1" />
//                                         {job.Job.estimatedDuration}
//                                     </div>
//                                 )}
//                                 {job.Job?.rating && job.Job.rating !== "0.0" && job.Job.rating !== null && (
//                                     <div className="flex items-center">
//                                         <Star size={14} className="mr-1 text-yellow-500 fill-yellow-500" />
//                                         {job.Job.rating}
//                                     </div>
//                                 )}
//                             </div>
//                         </div>
//                         <div className="text-sm text-gray-500 text-right">
//                             Applied on:<br />
//                             {new Date(job.appliedAt).toLocaleDateString('en-US', {
//                                 year: 'numeric', month: 'short', day: 'numeric'
//                             })}
//                         </div>
//                     </div>

//                     {/* User Application Section */}
//                     <div className="bg-gray-50 p-3 rounded-md">
//                         <h4 className="font-medium text-gray-700 mb-2 flex items-center">
//                             <User2 size={16} className="mr-2" /> User Application
//                         </h4>
//                         <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-sm text-gray-600">
//                             <div><span className="font-medium">Bidder:</span> {job.bidderName}</div>
//                             <div><span className="font-medium">Profile:</span> {job.profileName}</div>
//                             <div><span className="font-medium">Connects:</span> {job.connectsUsed}</div>
//                             <div className="col-span-2">
//                                 <span className="font-medium">Technologies:</span>
//                                 <div className="flex flex-wrap gap-1 mt-1">
//                                     {parsedTechnologies.slice(0, 3).map((tech, index) => (
//                                         <span key={index} className="bg-blue-100 text-blue-800 text-xs px-2 py-0.5 rounded">
//                                             {tech}
//                                         </span>
//                                     ))}
//                                     {parsedTechnologies.length > 3 && (
//                                         <span className="text-xs text-gray-500 ml-2">
//                                             +{parsedTechnologies.length - 3} more
//                                         </span>
//                                     )}
//                                 </div>
//                             </div>
//                         </div>
//                     </div>

//                     {/* Job Requirements Section */}
//                     {!isManualJob && job.Job && job.Job.experienceLevel && (
//                         <div className="bg-gray-50 p-3 rounded-md">
//                             <h4 className="font-medium text-gray-700 mb-2 flex items-center">
//                                 <Briefcase size={16} className="mr-2" /> Job Requirements
//                             </h4>
//                             <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-sm text-gray-600">
//                                 {job.Job.experienceLevel && (
//                                     <div><span className="font-medium">Level:</span> {job.Job.experienceLevel}</div>
//                                 )}
//                                 {job.Job.jobType && (
//                                     <div><span className="font-medium">Type:</span> {job.Job.jobType}</div>
//                                 )}
//                                 {job.Job.proposals && (
//                                     <div><span className="font-medium">Proposals:</span> {job.Job.proposals}</div>
//                                 )}
//                                 {job.Job.clientSpent && (
//                                     <div><span className="font-medium">Budget:</span> {job.Job.clientSpent}</div>
//                                 )}
//                                 {parsedTechStack.length > 0 && (
//                                     <div className="col-span-2">
//                                         <span className="font-medium">Tech Stack:</span>
//                                         <div className="flex flex-wrap gap-1 mt-1">
//                                             {parsedTechStack.slice(0, 4).map((tech, index) => (
//                                                 <span key={index} className="bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded">
//                                                     {tech}
//                                                 </span>
//                                             ))}
//                                             {parsedTechStack.length > 4 && (
//                                                 <span className="text-xs text-gray-500 ml-2">
//                                                     +{parsedTechStack.length - 4} more
//                                                 </span>
//                                             )}
//                                         </div>
//                                     </div>
//                                 )}
//                             </div>
//                         </div>
//                     )}

//                     {/* Action Buttons */}
//                     <div className="flex justify-end gap-2 pt-2 border-t border-gray-200 mt-2">
//                         <a
//                             href={job.proposalLink}
//                             target="_blank"
//                             rel="noopener noreferrer"
//                             className="text-xs bg-blue-500 px-3 py-1.5 rounded text-white hover:bg-blue-600"
//                         >
//                             View Proposal
//                         </a>
//                         <a
//                             href={job.Job?.link || job.manualJobUrl}
//                             target="_blank"
//                             rel="noopener noreferrer"
//                             className="text-xs bg-green-500 px-3 py-1.5 rounded text-white hover:bg-green-600"
//                         >
//                             View Job
//                         </a>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default AppliedJobsCard;
