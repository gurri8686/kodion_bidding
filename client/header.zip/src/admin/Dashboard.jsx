import { useState, useEffect } from 'react';
import {
  Users, Briefcase, Activity, TrendingUp
} from 'lucide-react';
import {
  LineChart, Line, AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid
} from 'recharts';
import Sidebar from '../components/Sidebar';
import axios from 'axios';
import { useSelector } from 'react-redux';
import { Loader } from '../utils/Loader';
import moment from 'moment';
import CountUp from 'react-countup';

const Dashboard = () => {
  const [count, setCount] = useState('')
  const [loading, setLoading] = useState(true);
  const [jobCount, setJobCount] = useState('')
  const [applyCount, setapplyCount] = useState('')
  const [topTechnologies, setTopTechnologies] = useState([]);
  const [logActivity, setLogActivity] = useState([]);
  const [viewMode, setViewMode] = useState("weekly");
  const token = useSelector((state) => state.auth.token);

  const fetchUserCount = async () => {
    const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/admin/allusers-count`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
    setCount(res.data.totalUsers);
  };

  const fetchJobCount = async () => {
    const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/admin/job-count`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
    setJobCount(res.data.totalJobs);
  };

  const fetchAppliedJobCount = async () => {
    const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/admin/appliedjob-count`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
    setapplyCount(res.data.totalAppliedJobs);
  };

  const topTech = async () => {
    const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/admin/top-tech`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
    setTopTechnologies(res.data);
  };

  const getScrapeSummary = async () => {
    const res = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/admin/get-scrape-log-summary`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });

    const formattedData = res.data.map(item => ({
      date: item.date,
      ScrapeLogs: Number(item.totalJobs),
    }));
    processChartData(formattedData);
  };

  const processChartData = (data) => {
    if (viewMode === "daily") {
      const formatted = data.map(d => ({
        ...d,
        date: moment(d.date).format("MMM D")
      }))
      setLogActivity(formatted);
    } else if (viewMode === "weekly") {
      const grouped = {};
      data.forEach(item => {
        const week = moment(item.date).startOf('isoWeek').format('YYYY-[W]WW');
        grouped[week] = (grouped[week] || 0) + item.ScrapeLogs;
      });
      const weeklyData = Object.entries(grouped).map(([weekStr, total]) => {
        const start = moment(weekStr, "YYYY-[W]WW").startOf("isoWeek");
        const end = moment(start).endOf("isoWeek");
        return {
          date: `${start.format("MMM D")} - ${end.format("D")}`,
          ScrapeLogs: total,
        };
      });
      setLogActivity(weeklyData);
    } else if (viewMode === "monthly") {
      const grouped = {};
      data.forEach(item => {
        const month = moment(item.date).format('MMM');
        grouped[month] = (grouped[month] || 0) + item.ScrapeLogs;
      });
      const monthlyData = Object.entries(grouped).map(([month, ScrapeLogs]) => ({ date: month, ScrapeLogs }));
      setLogActivity(monthlyData);
    } else if (viewMode === "yearly") {
      const grouped = {};
      data.forEach(item => {
        const year = moment(item.date).format('YYYY');
        grouped[year] = (grouped[year] || 0) + item.ScrapeLogs;
      });
      const yearlyData = Object.entries(grouped).map(([year, ScrapeLogs]) => ({ date: year, ScrapeLogs }));
      setLogActivity(yearlyData);
    }
  };

  useEffect(() => {
    const fetchAllData = async () => {
      try {
        setLoading(true);
        await Promise.all([
          fetchUserCount(),
          fetchJobCount(),
          fetchAppliedJobCount(),
          topTech(),
        ]);
      } catch (error) {
        console.error('Error loading dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAllData();
  }, []);

  useEffect(() => {
    getScrapeSummary();
  }, [viewMode]);

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      <div className="flex-1 p-8 overflow-y-auto mt-[20px] lg:mt-0">
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-orange-600 to-orange-600 bg-clip-text text-transparent mb-2">
            Admin Dashboard
          </h1>
          <p className="text-gray-600">Monitor your platform's performance and user activities</p>
        </div>
        {loading ? <Loader /> : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {/* Total Users */}
              <div className="bg-white rounded-3xl p-6 shadow-md border border-gray-100 hover:shadow-xl transition-shadow duration-300">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="p-3 rounded-full bg-blue-100">
                    <Users className="text-blue-600 w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-500">Total Users</p>
                    <h3 className="text-3xl font-bold text-gray-800">
                      <CountUp end={count} duration={2} separator="," />
                    </h3>
                  </div>
                </div>
              </div>
              {/* Total Jobs */}
              <div className="bg-white rounded-3xl p-6 shadow-md border border-gray-100 hover:shadow-xl transition-shadow duration-300">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="p-3 rounded-full bg-green-100">
                    <Briefcase className="text-green-600 w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-500">Total Jobs</p>
                    <h3 className="text-3xl font-bold text-gray-800">
                      <CountUp end={jobCount} duration={2} separator="," />
                    </h3>
                  </div>
                </div>
              </div>
              {/* Total Applications */}
              <div className="bg-white rounded-3xl p-6 shadow-md border border-gray-100 hover:shadow-xl transition-shadow duration-300">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="p-3 rounded-full bg-purple-100">
                    <Activity className="text-purple-600 w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-500">Total Applications</p>
                    <h3 className="text-3xl font-bold text-gray-800">
                      <CountUp end={applyCount} duration={2} separator="," />
                    </h3>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-lg border border-gray-100">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-gray-800">Scrape Log Activity</h2>
                <select
                  className="border border-gray-300 rounded-md px-2 py-1 text-sm"
                  value={viewMode}
                  onChange={(e) => setViewMode(e.target.value)}
                >
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                  <option value="yearly">Yearly</option>
                </select>
              </div>
              <div className="w-full h-64">
                <ResponsiveContainer width="100%" height="100%">
                  {viewMode === 'monthly' ? (
                    <AreaChart data={logActivity}>
                      <defs>
                        <linearGradient id="colorScrape" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#f97316" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Area type="monotone" dataKey="ScrapeLogs" stroke="#f97316" fillOpacity={1} fill="url(#colorScrape)" />
                    </AreaChart>
                  ) : (
                    <LineChart data={logActivity}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="ScrapeLogs" stroke="#f97316" strokeWidth={2} dot={{ r: 3 }} />
                    </LineChart>
                  )}
                </ResponsiveContainer>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Dashboard;