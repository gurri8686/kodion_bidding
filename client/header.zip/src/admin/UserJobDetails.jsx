import { useState, useEffect } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import axios from 'axios';
import Sidebar from '../components/Sidebar';
import { Loader } from '../utils/Loader';
import ReactPaginate from 'react-paginate';
import CustomTabs from './components/CustomTabs';
import UserLogs from './UserLogs';
const UserJobDetails = () => {
  const { userId } = useParams();
  console.log("User ID from params:", userId);
  const location = useLocation();
  const navigate = useNavigate();
  const token = useSelector((state) => state.auth.token);
  const [user, setUser] = useState(location.state?.user || null);
  const [activeTab, setActiveTab] = useState('applied');
  const [appliedJobs, setAppliedJobs] = useState([]);
  const [ignoredJobs, setIgnoredJobs] = useState([]);
  const [allAppliedJobs, setAllAppliedJobs] = useState([]);
  const [allIgnoredJobs, setAllIgnoredJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [dateFilterType, setDateFilterType] = useState('today');
  const [customDate, setCustomDate] = useState('');
  const jobsPerPage = 5;
  const [currentPage, setCurrentPage] = useState(0);

  useEffect(() => {
    if (!user && userId) fetchUserData();
  }, [userId, user]);

  useEffect(() => {
    fetchJobsForActiveTab();
    setCurrentPage(0);
  }, [activeTab, dateFilterType, customDate]);

  const fetchUserData = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/admin/user/${userId}/activity`,
        {
          headers: { Authorization: `Bearer ${token}` },
          withCredentials: true,
        }
      );
      setUser(response.data);
    } catch {
      setError('Failed to fetch user data');
    } finally {
      setLoading(false);
    }
  };

  const fetchJobsForActiveTab = async () => {
    try {
      setLoading(true);

      let dateToUse = new Date().toISOString().split('T')[0];
      if (dateFilterType === 'yesterday') {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        dateToUse = yesterday.toISOString().split('T')[0];
      } else if (dateFilterType === 'custom' && customDate) {
        dateToUse = customDate;
      }

      const isSameDate = (a, b) =>
        new Date(a).toISOString().split('T')[0] === b;

      if (activeTab === 'applied') {
        const appliedRes = await axios.get(
          `${import.meta.env.VITE_API_BASE_URL}/api/jobs/applied-jobs/${userId}`,
          {
            params: { date: dateToUse },
            headers: { Authorization: `Bearer ${token}` },
            withCredentials: true,
          }
        );
        const jobs = appliedRes.data.jobs || [];
        setAllAppliedJobs(jobs);
        setAppliedJobs(jobs.filter((job) => job.appliedAt && isSameDate(job.appliedAt, dateToUse)));
      }

      if (activeTab === 'ignored') {
        const ignoredRes = await axios.get(
          `${import.meta.env.VITE_API_BASE_URL}/api/jobs/get-ignored-jobs`,
          {
            params: { userId, date: dateToUse },
            headers: { Authorization: `Bearer ${token}` },
            withCredentials: true,
          }
        );
        const jobs = ignoredRes.data.jobs || [];
        setAllIgnoredJobs(jobs);
        setIgnoredJobs(jobs.filter((job) => job.ignoredAt && isSameDate(job.ignoredAt, dateToUse)));
      }

    } catch (err) {
      console.error(err);
      setError('Failed to fetch jobs');
    } finally {
      setLoading(false);
    }
  };

  const jobsToShow = activeTab === 'applied' ? appliedJobs : ignoredJobs;
  const pageCount = Math.ceil(jobsToShow.length / jobsPerPage);
  const paginatedJobs = jobsToShow.slice(currentPage * jobsPerPage, (currentPage + 1) * jobsPerPage);

  return (
    <div className="flex h-screen">
      <Sidebar />
      <div className="p-6 w-full overflow-y-auto">
        <button
          onClick={() => navigate('/admin/user-activity')}
          className="mb-4 text-blue-600 hover:text-blue-800"
        >
          ← Back to User Activity
        </button>

        {user && (
          <div className="mb-6">
            <h1 className="text-2xl font-bold">{user.name}</h1>
            <p className="text-gray-600">{user.email}</p>
          </div>
        )}

        <div className="flex gap-6 mb-4">

          <CustomTabs setActiveTab={setActiveTab} activeTab={activeTab} />
        </div>

        <div className="flex items-center gap-4 mb-4">
          <label className="text-sm font-medium">Filter by Date:</label>
          <select
            className="border px-3 py-2 rounded"
            value={dateFilterType}
            onChange={e => setDateFilterType(e.target.value)}
          >
            <option value="today">Today</option>
            <option value="yesterday">Yesterday</option>
            <option value="custom">Custom</option>
          </select>
          {dateFilterType === 'custom' && (
            <input
              type="date"
              className="border px-3 py-2 rounded"
              value={customDate}
              onChange={e => setCustomDate(e.target.value)}
            />
          )}
        </div>

        {loading ? (
          <Loader />
        ) : activeTab === 'logs' ? (
          <UserLogs userId={userId} dateFilterType={dateFilterType} setDateFilterType={setDateFilterType} customDate={customDate}  setCustomDate={setCustomDate} />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white border shadow-xl rounded-lg overflow-hidden">
                <thead className="bg-gray-50 sticky top-0 z-10">
                  <tr className="text-left text-sm font-bold text-gray-700">
                    {activeTab === 'applied' ? (
                      <>
                        <th className="p-4">Title</th>
                        <th className="p-4">Profile Used</th>
                        <th className="p-4">Connects Used</th>
                        <th className="p-4">Technology Applied</th>
                        <th className="p-4">Proposal Link</th>
                        <th className="p-4">Job Link</th>
                        <th className="p-4">Time of Apply</th>
                      </>
                    ) : (
                      <>
                        <th className="p-4">Title</th>
                        <th className="p-4">Location</th>
                        <th className="p-4">Job Type</th>
                        <th className="p-4">Price</th>
                        <th className="p-4">Reason</th>
                        <th className="p-4">Job Link</th>
                        <th className="p-4">Ignored Time</th>
                      </>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {paginatedJobs.length > 0 ? (
                    paginatedJobs.map((job, idx) => (
                      <tr
                        key={job.id || job.jobId}
                        className={`border-t text-sm transition-colors ${idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'} hover:bg-blue-50`}
                      >
                        {activeTab === 'applied' ? (
                          <>
                            <td className="p-4">{job.manualJobTitle || job.Job?.title || '—'}</td>
                            <td className="p-4">{job?.profile?.name ?? '—'}</td>
                            <td className="p-4">{job.connectsUsed ?? '—'}</td>
                            <td className="p-4">
                              {(() => {
                                if (job.technologies) {
                                  try {
                                    const techs = JSON.parse(job.technologies);
                                    return Array.isArray(techs) ? techs.join(', ') : job.technologies;
                                  } catch {
                                    return job.technologies;
                                  }
                                }
                                return '—';
                              })()}
                            </td>
                            <td className="p-4">
                              {job.proposalLink || job.manualJobUrl ? (
                                <a href={job.proposalLink || job.manualJobUrl} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline font-semibold">
                                  View Proposal
                                </a>
                              ) : '—'}
                            </td>
                            <td className="p-4">
                              {job.manualJobUrl || job.proposalLink ? (
                                <a href={job.manualJobUrl || job.proposalLink} target="_blank" rel="noopener noreferrer" className="text-green-600 hover:underline font-semibold">
                                  Job Link
                                </a>
                              ) : '—'}
                            </td>
                            <td className="p-4">
                              {job.appliedAt ? new Date(job.appliedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}
                            </td>
                          </>
                        ) : (
                          <>
                            <td className="p-4">{job.title || job.manualJobTitle}</td>
                            <td className="p-4">{job.clientLocation?.replace('Location\n', '') || '—'}</td>
                            <td className="p-4">{job.jobType || '—'}</td>
                            <td className="p-4">{job.fixedPrice || job.hourlyRate || '—'}</td>
                            <td className="p-4">{job.reason || job.customReason || '—'}</td>
                            <td className="p-4">
                              <a
                                href={job.link || job.manualJobUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-blue-600 hover:underline font-semibold"
                              >
                                View Job
                              </a>
                            </td>
                            <td className="p-4">
                              {job.ignoredAt ? new Date(job.ignoredAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}
                            </td>
                          </>
                        )}
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td className="p-4 text-center text-gray-500" colSpan={7}>
                        No {activeTab} jobs found for selected date.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            {pageCount > 1 && (
              <div className="flex justify-center mt-6">
                <ReactPaginate
                  previousLabel={"← Previous"}
                  nextLabel={"Next →"}
                  pageCount={pageCount}
                  onPageChange={({ selected }) => setCurrentPage(selected)}
                  forcePage={currentPage}
                  containerClassName={"flex text-sm space-x-2"}
                  pageClassName="px-4 py-2 border rounded-lg bg-gray-200 hover:bg-blue-500 hover:text-white"
                  previousClassName="px-4 py-2 border rounded-lg bg-gray-300 hover:bg-gray-400"
                  nextClassName="px-4 py-2 border rounded-lg bg-gray-300 hover:bg-gray-400"
                  activeClassName="bg-blue-600 border-blue-600 text-white"
                  disabledClassName="opacity-50 cursor-not-allowed"
                />
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default UserJobDetails;
