import { useState, useEffect } from "react";
import Sidebar from "../components/Sidebar";
import axios from "axios";
import { useSelector } from "react-redux";
import { Loader } from "../utils/Loader";
import { useNavigate } from "react-router-dom";

const UserActivity = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const token = useSelector((state) => state.auth.token);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      try {
        const res = await axios.get(
          `${import.meta.env.VITE_API_BASE_URL}/api/admin/allusers`,
          {
            headers: { Authorization: `Bearer ${token}` },
            withCredentials: true,
          }
        );

        const userData = await Promise.all(
          res.data.map(async (user) => {
            const detailRes = await axios.get(
              `${import.meta.env.VITE_API_BASE_URL}/api/admin/user/${user.id}/activity`,
              {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true,
              }
            );
            return detailRes.data;
          })
        );

        setUsers(userData);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, [token]);

  return (
    <div className="flex flex-col md:flex-row h-screen overflow-hidden">
      <Sidebar />
      <div className="p-4 flex-1 flex flex-col overflow-y-auto">
        <div className="mb-6">
          <h1 className="text-xl md:text-2xl mt-[40px] lg:mt-0 font-bold text-gray-900">
            User Activity Dashboard
          </h1>
          <p className="text-gray-600 mt-1 text-sm">
            Monitor all user activities and job interactions
          </p>
        </div>
        {loading ? (
          <div className="flex items-center justify-center min-h-[300px] w-full">
            <Loader />
          </div>
        ) : (
          <div className="overflow-x-auto w-full">
            <table className="min-w-[700px] w-full bg-white border text-sm">
              <thead>
                <tr className="bg-gray-100 text-left font-semibold text-gray-700">
                  <th className="p-3">Name</th>
                  <th className="p-3">Email</th>
                  <th className="p-3 text-blue-600">Applied</th>
                  <th className="p-3 text-yellow-600">Ignored</th>
                  <th className="p-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id} className="border-t">
                    <td className="p-3 whitespace-nowrap">{user.name}</td>
                    <td className="p-3 whitespace-nowrap">{user.email}</td>
                    <td className="p-3 whitespace-nowrap">{user.appliedJobs}</td>
                    <td className="p-3 whitespace-nowrap">{user.ignoredJobs}</td>
                    <td className="p-3 whitespace-nowrap">
                      <button
                        onClick={() =>
                          navigate(`/admin/user/${user.id}/jobs`, {
                            state: { user, token },
                          })
                        }
                        className="text-blue-500 hover:underline"
                      >
                        View Jobs
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserActivity;
