import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useSelector } from 'react-redux';

const parseJson = (str) => {
  try {
    return JSON.parse(str);
  } catch (e) {
    return {};
  }
};

const getChangedFields = (oldData, newData) => {
  const changes = [];
  for (const key in newData) {
    if (key === 'updated_at' || key === 'updatedAt') continue; // Skip timestamp fields

    const normalize = (val) => {
      if (typeof val === "string") {
        try {
          const parsed = JSON.parse(val);
          if (Array.isArray(parsed) || typeof parsed === "object") return parsed;
        } catch (_) {
          // not JSON
        }
      }
      return val;
    };

    if (JSON.stringify(normalize(oldData[key])) !== JSON.stringify(normalize(newData[key]))) {
      changes.push({
        field: key,
        old: oldData[key],
        new: newData[key],
      });
    }
  }
  return changes;
};

const UserLogs = ({ userId, dateFilterType, setDateFilterType, customDate, setCustomDate }) => {
  const token = useSelector((state) => state.auth.token);
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  // Helper to calculate the selected date
const getSelectedDate = () => {
  let dateToUse;

  if (dateFilterType === 'yesterday') {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    dateToUse = yesterday;
  } else if (dateFilterType === 'custom' && customDate) {
    return customDate; // already in YYYY-MM-DD format
  } else {
    dateToUse = new Date();
  }

  // Adjust to UTC and return YYYY-MM-DD
  return new Date(dateToUse.getTime() - dateToUse.getTimezoneOffset() * 60000)
    .toISOString()
    .split('T')[0];
};


  useEffect(() => {
    const fetchLogs = async () => {
      setLoading(true);
      try {
        const dateToUse = getSelectedDate();
        console.log(dateToUse,'date-to-use');
        const response = await axios.get(
          `${import.meta.env.VITE_API_BASE_URL}/api/admin/logs/${userId}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
            params: { date: dateToUse }, // ✅ send date to backend
          }
        );

        if (response.data.success) {
          setLogs(response.data.logs);
        } else {
          console.error('Failed to fetch logs:', response.data.message);
        }
      } catch (error) {
        console.error('Error fetching logs:', error);
      } finally {
        setLoading(false);
      }
    };

    if (userId && token) {
      fetchLogs();
    }
  }, [userId, token, dateFilterType, customDate]); // refresh when date changes

  return (
    <div className="p-4 bg-white shadow rounded overflow-x-auto">
      <h2 className="text-lg font-semibold mb-4">User Edit Activity Logs</h2>

      {loading ? (
        <p>Loading logs...</p>
      ) : logs.length === 0 ? (
        <p>No logs found for the selected date.</p>
      ) : (
        logs.map((log, idx) => {
          const oldData = parseJson(log.oldData);
          const newData = parseJson(log.newData);
          let changes = getChangedFields(oldData, newData);

          // Replace profileId with profile name if available
          changes = changes.map(change => {
            if (change.field === 'profileId' && log.appliedJob?.profile?.name) {
              return {
                ...change,
                field: 'profile',
                old: oldData.profile?.name || '',
                new: log.appliedJob.profile.name || '',
              };
            }
            return change;
          });

          return (
            <div key={idx} className="mb-6 border-b pb-4">
              {/* Job title */}
              <div className="mb-1 font-semibold text-blue-800">
                Job: {log.appliedJob?.manual_job_title || oldData.manualJobTitle || 'Unknown Job'}
              </div>

              <div className="mb-2 text-sm text-gray-600">
                <span className="font-medium capitalize">{log.changeType}</span> at{' '}
                <span className="text-blue-600">{new Date(log.createdAt).toLocaleString()}</span>
              </div>

              {changes.length > 0 ? (
                <table className="min-w-full text-sm table-auto border border-gray-200">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="border px-4 py-2 text-left">Field</th>
                      <th className="border px-4 py-2 text-left text-red-600">Old Value</th>
                      <th className="border px-4 py-2 text-left text-green-600">New Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    {changes.map((change, i) => (
                      <tr key={i} className="border-t">
                        <td className="px-4 py-2 font-medium">{change.field}</td>
                        <td className="px-4 py-2 text-red-700 break-all">{String(change.old)}</td>
                        <td className="px-4 py-2 text-green-700 break-all">{String(change.new)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="text-gray-400">No changes detected.</div>
              )}
            </div>
          );
        })
      )}
    </div>
  );
};

export default UserLogs;
