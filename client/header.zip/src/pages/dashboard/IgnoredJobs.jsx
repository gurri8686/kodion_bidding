import React, { useEffect, useState } from "react";
import Sidebar from "../../components/Sidebar";
import axios from "axios";
import JobFilters from "../../components/JobFilters";
import { useSelector } from "react-redux";
import { Loader } from "../../utils/Loader";
import ReactPaginate from "react-paginate";
import JobCard from "../../components/cards/JobCard";

const IgnoredJobs = () => {
  const [ignoredJobs, setIgnoredJobs] = useState([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [isApplying, setIsApplying] = useState(false);
  const [totalPages, setTotalPages] = useState(0);
  const jobsPerPage = 6;
  const [filters, setFilters] = useState({
    selectedTechnologies: [],
    rating: null,
    startDate: null,
    endDate: null,
    searchTerm: '',
    jobType: 'all',
    hourlyMinRate: '',
    hourlyMaxRate: '',
    fixedPriceRange: '',
    customFixedMin: '',
    customFixedMax: ''
  });
  const userId = useSelector((state) => state.auth.userId);
  const token = useSelector((state) => state.auth.token);
  const [totalCount, setTotalCount] = useState(0);

  const fetchIgnoredJobs = async (page = 1) => {
    setIsLoading(true);

    const {
      selectedTechnologies,
      rating,
      startDate,
      endDate,
      searchTerm,
      jobType,
      hourlyMinRate,
      hourlyMaxRate,
      fixedPriceRange,
      customFixedMin,
      customFixedMax
    } = filters;

    const params = {
      userId,
      page,
      limit: jobsPerPage,
      rating: rating || undefined,
      tech: selectedTechnologies.length > 0 ? selectedTechnologies.map(t => t.value) : undefined,
      jobType: jobType !== 'all' ? jobType : undefined,
      hourlyMinRate: jobType === 'hourly' && hourlyMinRate ? hourlyMinRate : undefined,
      hourlyMaxRate: jobType === 'hourly' && hourlyMaxRate ? hourlyMaxRate : undefined,
      fixedPriceRange: jobType === 'fixed' ? fixedPriceRange : undefined,
      customFixedMin: jobType === 'fixed' && fixedPriceRange === 'custom' ? customFixedMin : undefined,
      customFixedMax: jobType === 'fixed' && fixedPriceRange === 'custom' ? customFixedMax : undefined,
      title: typeof searchTerm === 'string' ? searchTerm.trim() : undefined,
      startDate: startDate ? startDate.toLocaleDateString('en-CA') : undefined,
      endDate: endDate ? endDate.toLocaleDateString('en-CA') : undefined,
    };
    if (startDate) params.startDate = startDate.toLocaleDateString('en-CA');
    if (endDate) params.endDate = endDate.toLocaleDateString('en-CA');
    console.log("Fetching ignored jobs with params:", params);
    try {
      const response = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/jobs/get-ignored-jobs`,
        {
          params,
          headers: {
            Authorization: `Bearer ${token}`,
          },
          withCredentials: true,
        }
      );

      setIgnoredJobs(response.data.jobs || []);
      setTotalPages(response.data.totalPages);
      setCurrentPage(response.data.currentPage - 1);
      setTotalCount(response.data.totalCount);
    } catch (err) {
      console.error("Error fetching ignored jobs:", err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApplyFilter = async () => {
    setIsApplying(true);
    try {
      await fetchIgnoredJobs(1); // or current page
    } catch (error) {
      console.error("Error applying filters:", error);
    } finally {
      setIsApplying(false);
    }
  };;

  const clearFilters = () => {
    setFilters({
      selectedTechnologies: [],
      rating: null,
      startDate: null,
      endDate: null,
      searchTerm: '',
      jobType: 'all',
      hourlyMinRate: '',
      hourlyMaxRate: '',
      fixedPriceRange: '',
      customFixedMin: '',
      customFixedMax: ''
    });
    setCurrentPage(0);
  };

  const handlePageChange = ({ selected }) => {
    fetchIgnoredJobs(selected + 1); // zero-based UI page to 1-based API page
  };

  // Initial fetch when userId or token changes
  useEffect(() => {
    if (userId && token) {
      fetchIgnoredJobs(1);
    }
  }, [userId, token, filters]);


  const handleApplyJob = async (jobId) => {
    fetchIgnoredJobs(1);
    setJobId(jobId);
    setApplyModal(true);
  }


  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      <main className="flex-1 p-8 overflow-y-scroll">
        <div className="flex lg:items-center mt-[40px] lg:mt-0 lg:flex-row flex-col justify-between mb-3">
          <h1 className="text-2xl font-bold ">Ignored Jobs</h1>
          <p className="text-gray-700 font-medium">
            Displaying <span className="font-bold">{ignoredJobs.length}</span> job{ignoredJobs.length !== 1 ? 's' : ''} on this page — <span className="font-bold">{totalCount}</span> job{totalCount !== 1 ? 's' : ''} found in total
          </p>
        </div>
        <JobFilters
          filters={filters}
          setFilters={setFilters}
          isApplying={isApplying}
          handleApplyFilter={handleApplyFilter}
          handleClearFilter={clearFilters}
          fetchJobs={fetchIgnoredJobs}
          setIsLoading={setIsLoading}
        />
        {isLoading ? (
          <Loader />
        ) : (
          <>
            <div className="grid lg:grid-cols-2 grid-cols-1 gap-6">
              {ignoredJobs.length > 0 ? (
                ignoredJobs.map((job, index) => (
                  <JobCard
                    key={job.jobId}
                    job={job}
                    mode="ignored"
                    onApply={handleApplyJob}
                  />
                ))
              ) : (
                <p className="text-center text-gray-600 text-lg flex justify-center mt-[130px] mx-auto">
                  No jobs found matching your filters
                </p>
              )}
              {ignoredJobs.length > 5 && (
                <div className="flex justify-center mt-8">
                  <ReactPaginate
                    previousLabel={"← Previous"}
                    nextLabel={"Next →"}
                    pageCount={totalPages}
                    onPageChange={handlePageChange}
                    forcePage={currentPage} // ensures current page stays in sync
                    containerClassName={"flex text-sm space-x-2"}
                    pageClassName="px-4 py-2 border rounded-lg bg-gray-200 hover:bg-blue-500 hover:text-white"
                    previousClassName="px-4 py-2 border rounded-lg bg-gray-300 hover:bg-gray-400"
                    nextClassName="px-4 py-2 border rounded-lg bg-gray-300 hover:bg-gray-400"
                    activeClassName="bg-blue-600 border-blue-600"
                    disabledClassName="opacity-50 cursor-not-allowed"
                  />
                </div>
              )}
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default IgnoredJobs;