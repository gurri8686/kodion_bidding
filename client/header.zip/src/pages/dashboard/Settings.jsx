import { useState, useEffect } from 'react';
import Sidebar from '../../components/Sidebar';
import { useSelector } from 'react-redux';
import { toast, ToastContainer } from "react-toastify";
import { Loader } from '../../utils/Loader';
import "react-toastify/dist/ReactToastify.css";

const Settings = () => {
  const [activeTech, setActiveTech] = useState([]);
  const [allTechnologies, setAllTechnologies] = useState([]);
  const [loading, setLoading] = useState(true);
  const userId = useSelector((state) => state.auth.userId);
  const token = useSelector((state) => state.auth.token);

  useEffect(() => {
    fetchTechOptions();
    fetchActiveTechnologies();
  }, []);

  
  const fetchTechOptions = async () => {
    try {
      const baseUrl = import.meta.env.VITE_API_BASE_URL;
      const endpoint = `${baseUrl}/api/jobs/all-technology-names`;

      const response = await fetch(endpoint, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        credentials: "include",
      });

      const data = await response.json();

      if (response.ok && Array.isArray(data.technologies)) {
        setAllTechnologies(data.technologies); // already strings
      } else {
        console.error("Unexpected format or error fetching tech list:", data);
        setAllTechnologies([]);
      }
    } catch (error) {
      console.error("Failed to load technologies:", error);
    }
  };

  const fetchActiveTechnologies = async () => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/jobs/active/${userId}`, {
        headers: { Authorization: `Bearer ${token}` },
        credentials: "include",
      });

      const data = await response.json();

      if (response.ok) {
        const techNames = data.technologies
          .filter((tech) => tech.is_active)
          .map((tech) => tech.name);
        setActiveTech(techNames);
      } else {
        console.error('Error fetching active technologies:', data);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleToggle = async (tech) => {
    const isActive = activeTech.includes(tech);
    const endpoint = isActive ? 'deactivate' : 'activate';

    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/jobs/${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ userId, technologyName: tech }),
      });

      if (response.ok) {
        setActiveTech(prev =>
          isActive ? prev.filter(t => t !== tech) : [...prev, tech]
        );
        toast.success(`${tech} ${isActive ? 'removed' : 'added'} successfully.`);
      } else {
        toast.error(`Failed to ${isActive ? 'remove' : 'add'} technology.`);
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error("An error occurred.");
    }
  };

  return (
    <div className="flex bg-gray-100 h-screen">
      <Sidebar />
      {loading ? (
        <div className='grid grid-cols-1 mx-auto'>
          <Loader />
        </div>
      ) : (
        <div className="flex-1 p-8 overflow-y-auto mt-[20px] lg:mt-0">
          <ToastContainer position="top-center" autoClose={2000} />
          <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-md p-6">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">Manage Your Technologies</h2>

            <div className="space-y-4">
              {allTechnologies.length > 0 ? (
                allTechnologies.map((tech) => (
                  <div key={tech} className="flex items-center justify-between">
                    <span className="text-gray-700 font-medium">{tech}</span>
                    <label className="inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        className="sr-only peer"
                        checked={activeTech.includes(tech)}
                        onChange={() => handleToggle(tech)}
                      />
                      <div className="relative w-11 h-6 bg-gray-200 rounded-full peer peer-checked:bg-blue-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-full" />
                    </label>
                  </div>
                ))
              ) : (
                <p className="text-gray-500">No technologies found.</p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Settings;
