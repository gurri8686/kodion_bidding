import { useEffect, useState } from 'react';
import Sidebar from "../../components/Sidebar";
import { Loader } from '../../utils/Loader';
import { useSelector } from 'react-redux';
import ReactPaginate from "react-paginate";
import axios from "axios";
import JobFilters from '../../components/JobFilters';
import ApplyManualJob from '../../modals/ApplyManualJob'
import AppliedJobCard from '../../components/cards/AppliedCard';


const AppliedJobs = () => {
  const [appliedJobs, setAppliedJobs] = useState([]);
  const [applyModal, setApplyModal] = useState(false);
  const [totalPages, setTotalPages] = useState(0);
  const [currentPage, setCurrentPage] = useState(0); // Changed to 0-based index
  const jobsPerPage = 6;
  const [totalCount, setTotalCount] = useState(0);
  const [isApplying, setIsApplying] = useState(false); // ← NEW STATE
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const user = useSelector((state) => state.auth.user);
  const token = useSelector((state) => state.auth.token);
  const userId = user.id;
  const [filters, setFilters] = useState({
    selectedTechnologies: [],
    rating: null,
    startDate: null,
    endDate: null,
    searchTerm: '',
    jobType: 'all',
    hourlyMinRate: '',
    hourlyMaxRate: '',
    fixedPriceRange: '',
    customFixedMin: '',
    customFixedMax: ''
  });
  const fetchAppliedJobs = async (page = 1) => {
    setLoading(true);
    const {
      selectedTechnologies,
      rating,
      startDate,
      endDate,
      searchTerm,
      jobType,
      hourlyMinRate,
      hourlyMaxRate,
      fixedPriceRange,
      customFixedMin,
      customFixedMax
    } = filters;
    const params = {
      userId,
      page,
      limit: jobsPerPage,
      rating: rating || undefined,
      tech: selectedTechnologies.length > 0 ? selectedTechnologies.map(t => t.value) : undefined,
      jobType: jobType !== 'all' ? jobType : undefined,
      hourlyMinRate: jobType === 'hourly' && hourlyMinRate ? hourlyMinRate : undefined,
      hourlyMaxRate: jobType === 'hourly' && hourlyMaxRate ? hourlyMaxRate : undefined,
      fixedPriceRange: jobType === 'fixed' ? fixedPriceRange : undefined,
      customFixedMin: jobType === 'fixed' && fixedPriceRange === 'custom' ? customFixedMin : undefined,
      customFixedMax: jobType === 'fixed' && fixedPriceRange === 'custom' ? customFixedMax : undefined,
      title: searchTerm?.trim() || undefined,
      startDate: startDate ? startDate.toLocaleDateString('en-CA') : undefined,
      endDate: endDate ? endDate.toLocaleDateString('en-CA') : undefined,
    };
    // Build params with filters + pagination


    const adjustDateToMidday = (date) => {
      const newDate = new Date(date);
      newDate.setHours(12, 0, 0, 0); // Set time to 12:00 PM to avoid timezone shift issues
      return newDate.toISOString().split("T")[0];
    };

    if (startDate) params.startDate = adjustDateToMidday(startDate);
    if (endDate) params.endDate = adjustDateToMidday(endDate);

    try {
      const response = await axios.get(
        `${import.meta.env.VITE_API_BASE_URL}/api/jobs/applied-jobs/${userId}`,
        {
          params,
          headers: {
            Authorization: `Bearer ${token}`,
          },
          withCredentials: true,
        }
      );

      setTotalCount(response.data.totalCount);
      setAppliedJobs(response.data.jobs);
      setTotalPages(response.data.totalPages);
      setCurrentPage(response.data.currentPage - 1); // Assuming API currentPage is 1-based
    } catch (err) {
      setError(err.response?.data?.message || err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleApplyFilter = () => {
    fetchAppliedJobs(1); // Fetch page 1 with current filters
  };

  const handleClearFilter = () => {
    setStartDate(null);
    setEndDate(null);
    setSelectedTechnologies([]);
    setRatingFilter(null);
    fetchAppliedJobs(1); // Fetch page 1 with cleared filters
  };
  const handleApply = async () => {
    fetchAppliedJobs(1);
    // onApply();
    setApplyModal(false);
  }

  const handlePageChange = ({ selected }) => {
    fetchAppliedJobs(selected + 1); // Pagination component zero-based, API 1-based
  };

  // Initial fetch on mount
  useEffect(() => {
    fetchAppliedJobs(1);
  }, [filters]);



  return (
    <>
      <div className="flex h-screen bg-gray-100">
        <Sidebar />
        <main className="flex-1 p-8 overflow-y-auto">
          <div className="flex justify-between lg:flex-row flex-col mt-[40px] lg:mt-0 lg:items-center mb-3">
            <h1 className="text-2xl font-bold ">Applied Jobs</h1>
            <p className="text-gray-700 font-medium">
              Displaying <span className="font-bold">{appliedJobs.length}</span> job{appliedJobs.length !== 1 ? 's' : ''} on this page — <span className="font-bold">{totalCount}</span> job{totalCount !== 1 ? 's' : ''} found in total
            </p>
          </div>
          {/* <JobFilters
            filters={filters}
            setFilters={setFilters}
            isApplying={isApplying}
            handleApplyFilter={handleApplyFilter}
            handleClearFilter={handleClearFilter}
            fetchJobs={fetchAppliedJobs}
            setIsLoading={setLoading}
          /> */}

          <ApplyManualJob
            isOpen={applyModal}
            onRequestClose={() => setApplyModal(false)}
            onApplyJob={handleApply}
            fetchAppliedJobs={fetchAppliedJobs}
          />
          <button
            onClick={() => setApplyModal(true)}
            className="bg-blue-600 text-white px-4 py-2  mb-4 rounded-md hover:bg-blue-700 transition-colors"
          >
            Add Manual Job
          </button>
          <div className="grid lg:grid-cols-2 grid-cols-1 gap-6">
            {loading ? (
           <div className="w-full flex justify-center items-center py-20 col-span-2">
           <Loader />
         </div>
            ) : appliedJobs.length === 0 ? (
              <p className="text-center text-gray-600 text-lg flex justify-center mt-[130px] mx-auto">
                No jobs found matching your filters.
              </p>
            ) : (
              appliedJobs?.map((job) => {
                // Helper function to check if it's a manual jo
         return          <AppliedJobCard key={job.id} job={job} fetchAppliedJobs={fetchAppliedJobs} />

              })
            )}
          </div>

          {!loading && appliedJobs.length > 5 && (
            <div className="mt-8 flex justify-center">
              <ReactPaginate
                previousLabel={"← Previous"}
                nextLabel={"Next →"}
                pageCount={totalPages}
                onPageChange={handlePageChange}
                containerClassName={"flex text-sm  space-x-2"}
                pageClassName="px-4 py-2 border rounded-lg bg-gray-200 hover:bg-blue-500 hover:text-white"
                previousClassName="px-4 py-2 border rounded-lg bg-gray-300 hover:bg-gray-400"
                nextClassName="px-4 py-2 border rounded-lg bg-gray-300 hover:bg-gray-400"
                activeClassName="bg-blue-600 border-blue-600"
                disabledClassName="opacity-50 cursor-not-allowed"
                forcePage={currentPage}
              />
            </div>
          )}
        </main>
      </div>
    </>
  );
};

export default AppliedJobs;