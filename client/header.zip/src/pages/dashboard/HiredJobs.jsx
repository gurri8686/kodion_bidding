import React, { useEffect, useState } from 'react';
import Sidebar from "../../components/Sidebar";
import HiredJobsCard from '../../components/cards/HiredJobsCard';
import axios from 'axios';
import { useSelector } from 'react-redux';
const HiredJobs = () => {
  const [hiredJobs, setHiredJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const token = useSelector((state) => state.auth.token);
  const bidderId = localStorage.getItem("userId"); // Make sure this key matches your login setup
  const API = import.meta.env.VITE_API_BASE_URL;

  useEffect(() => {
    const fetchHiredJobs = async () => {
      try {
        const res = await axios.get(`${API}/api/jobs/get-hired-jobs/${bidderId}`,
           {
          headers: {
            Authorization: `Bearer ${token}`,
          },
          withCredentials: true,
        }
        );
        setHiredJobs(res.data.hiredJobs);
      } catch (err) {
        console.error("Failed to fetch hired jobs:", err);
      } finally {
        setLoading(false);
      }
    };

    if (bidderId) {
      fetchHiredJobs();
    }
  }, [bidderId]);

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      <main className="flex-1 p-8 overflow-y-scroll">
        <h1 className="text-2xl font-semibold mb-6">Hired Jobs</h1>

        {loading ? (
          <div>Loading...</div>
        ) : hiredJobs.length === 0 ? (
          <div>No hired jobs found.</div>
        ) : (
          <div className="grid lg:grid-cols-2 grid-cols-1 gap-4">
            {hiredJobs.map((job) => (
              <HiredJobsCard key={job.id} job={job} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default HiredJobs;
