import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { useSelector } from "react-redux";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Jobs from "./pages/dashboard/Job";
import PrivateRoute from "./components/PrivateRoute";
import PublicRoute from "./components/PublicRoute";
import Profile from "./pages/dashboard/Profile";
import AppliedJobs from "./pages/dashboard/AppliedJobs";
import IgnoredJobs from "./pages/dashboard/IgnoredJobs";
import ScrapeLogs from "./pages/dashboard/ScrapeLogs";
import Dashboard from "./admin/Dashboard";
import Settings from "./pages/dashboard/Settings";
import "./App.css";
import UserActivity from "./admin/UserActivity";
import AllUsers from "./admin/Allusers";
import UserJobDetails from "./admin/UserJobDetails";
import HiredJobs from "./pages/dashboard/HiredJobs";
import ManageDevelopers from "./pages/dashboard/ManageDevelopers";
import { Loader } from "./utils/Loader";


function App() {
  const token = useSelector((state) => state?.auth?.token);
  const user = useSelector((state) => state?.auth?.user);
  const role = user?.role;
  // Optional loading guard if user info isn't ready
  if (token && !role) {
    return <div><Loader/></div>;
  }
  
  return (  
    <Router>
      <Routes>
        {/* Redirect root path based on token and role */}
        <Route
          path="/"
          element={
            token ? (
              role === "admin" ? (
                <Navigate to="/admin/dashboard" replace />
              ) : (
                <Navigate to="/dashboard/jobs" replace />
              )
            ) : (
              <Navigate to="/login" replace />
            )
          }
        />

        {/* Public Routes */}
        <Route element={<PublicRoute />}>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
        </Route>

        {/* Admin Routes */}
        {role === "admin" && (
          <>
            <Route path="/admin/dashboard" element={<Dashboard />} />
            <Route path="/admin/jobs" element={<Jobs />} />
            <Route path="/admin/applied-jobs" element={<AppliedJobs />} />
            <Route path="/admin/ignored-jobs" element={<IgnoredJobs />} />
            <Route path="/admin/users" element={<AllUsers />} />
            <Route path="/admin/user-activity" element={<UserActivity />} />
            <Route path="/admin/scrape-logs" element={<ScrapeLogs />} />
            <Route path="/admin/user/:userId/jobs" element={<UserJobDetails />} />
          </>
        )}

        {/* Protected User Routes */}
        <Route element={<PrivateRoute />}>
          <Route path="/dashboard/jobs" element={<Jobs />} />
          <Route path="/dashboard/profile" element={<Profile />} />
          <Route path="/dashboard/applied-jobs" element={<AppliedJobs />} />
          <Route path="/dashboard/ignored-jobs" element={<IgnoredJobs />} />
          <Route path="/dashboard/hired-jobs" element={<HiredJobs />} />
           <Route path="/dashboard/manage-developers" element={<ManageDevelopers />} />
          {/* 👇 Conditional scrape logs route for non-admin users only */}
          <Route
            path="/dashboard/scrape-logs"
            element={
              role === "admin" ? (
                <Navigate to="/admin/scrape-logs" replace />
              ) : (
                <ScrapeLogs />
              )
            }
          />

          <Route path="/dashboard/settings" element={<Settings />} />
        </Route>

        {/* Catch-all */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
